﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

public partial class Website_Homepage : System.Web.UI.Page
{
    public string username;
    public List<String> blacklist = new List<String>();
    
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (Session["username"] == null || Session["username"] == null)
        {
            username = "anonymous";
        }
        else
        {
            username = (String)Session["username"];
        }

        blacklist = Searchdatabaseforblacklist();

    }

    //retrieve blacklist table data
    public List<String> Searchdatabaseforblacklist()
    {
        //List<music> al = new List<music>();
        List<String> blacklisturl = new List<String>();
        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT URL FROM blacklistlinks";
            MySqlCommand command = new MySqlCommand(query, con);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    blacklisturl.Add(reader.GetString(reader.GetOrdinal("URL")));
                }

                if (reader != null)
                    reader.Close();
            }

        }
        return blacklisturl;
    }

}