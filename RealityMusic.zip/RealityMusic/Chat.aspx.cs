﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Chat : System.Web.UI.Page
{
    public string username;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["username"] == null || Session["username"] == null)
        {
            username = "anonymous";
        }
        else
        {
            username = (String)Session["username"];
        }
    }
}