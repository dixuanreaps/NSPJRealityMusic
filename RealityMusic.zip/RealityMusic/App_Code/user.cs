﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for user
/// </summary>
public class user
{

    public int Userid { get; set; }
    public String email { get; set; }
    public String userName { get; set; }
    public String phonenumber { get; set; }
    public String firstname { get; set; }
    public String lastname { get; set; }
    public String country { get; set; }
    public String imagepath { get; set; }
    public String birthdate { get; set; }


    public user(int Userid, string email, string username, string phonenumber, string firstname, string lastname, string country, string imagepath, string birthdate)
    {
        this.Userid = Userid;
        this.email = email;
        this.userName = username;
        this.phonenumber = phonenumber;
        this.firstname = firstname;
        this.lastname = lastname;
        this.country = country;
        this.imagepath = imagepath;
        this.birthdate = birthdate;
    }
}