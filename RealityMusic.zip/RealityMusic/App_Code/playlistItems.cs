﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for playlist
/// </summary>
public class playlistItems
{
    public String audioID { get; set; }
    public int userid { get; set; }
    public String playlistName { get; set; }
    public String playlistID { get; set; }
    public String musicTitle { get; set; }

    public playlistItems(String audioID, int userid, String playlistName, String playlistID, String musicTitle)
    {
        this.audioID = audioID;
        this.userid = userid;
        this.playlistName = playlistName;
        this.playlistID = playlistID;
        this.musicTitle = musicTitle;
    }
}