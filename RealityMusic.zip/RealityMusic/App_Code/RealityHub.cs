﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

[HubName("realityHub")]
public class RealityHub : Hub
{
    public List<String> blacklist = new List<String>();

    public void Send(string name, string message)
    {
        blacklist = Searchdatabaseforblacklist();
        int count = 0;
        while(blacklist.Count > count)
        {
            String url = blacklist[count];
            if (message.Contains(url))
            {
                message = message.Replace("https://www."+url, "Malicious Website Detected");
                message = message.Replace("https://" + url, "Malicious Website Detected");
                message = message.Replace("http://www." + url, "Malicious Website Detected");
                message = message.Replace("http://" + url, "Malicious Website Detected");
                message = message.Replace("www." + url, "Malicious Website Detected");
                message = message.Replace("m." + url, "Malicious Website Detected");
                message = message.Replace("web." + url, "Malicious Website Detected");
                message = message.Replace(url, "Malicious Website Detected");
            }
            count++;
        }
        if(message.Contains("fuck") || message.Contains("shit") || message.Contains("damn") || message.Contains("porn") || message.Contains("asshole"))
        {
            message = message.Replace("fucker", "****");
            message = message.Replace("fuck", "****");
            message = message.Replace("shit", "****");
            message = message.Replace("damn", "****");
            message = message.Replace("porn", "****");
            message = message.Replace("asshole", "****");
        }
        // Call the broadcastMessage method to update clients.
        Clients.All.broadcastMessage(name, message);
    }

    //retrieve blacklist table data
    public List<String> Searchdatabaseforblacklist()
    {
        List<String> blacklistURL = new List<String>();

        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT * FROM blacklistlinks";
            MySqlCommand command = new MySqlCommand(query, con);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    blacklistURL.Add(reader.GetString(reader.GetOrdinal("URL")));
                }

                if (reader != null)
                    reader.Close();
            }

        }
        return blacklistURL;
    }
}
