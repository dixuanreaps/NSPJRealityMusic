﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for music
/// </summary>
public class music
{
    public String Musicid { get; set; }
    public int Userid { get; set; }
    public String MusicTitle { get; set; }
    public String Description { get; set; }
    public String AudioPath { get; set; }
    public String ImagePath { get; set; }
    public String PriceType { get; set; }
    public String UploadDate { get; set; }
    public int Views { get; set; }
    public int Likes { get; set; }
    public int NoOfReports { get; set; }

    public music(String musicid, int userid, String MusicTitle, String description, String audioPath, String imagePath, String priceType, String uploadDate, int views, int likes, int noOfreports)
    {
        this.Musicid = musicid;
        this.Userid = userid;
        this.MusicTitle = MusicTitle;
        this.Description =description;
        this.AudioPath = audioPath;
        this.ImagePath = imagePath;
        this.PriceType = priceType;
        this.UploadDate = uploadDate;
        this.Views = views;
        this.Likes =  likes;
        this.NoOfReports = noOfreports;
    }
}