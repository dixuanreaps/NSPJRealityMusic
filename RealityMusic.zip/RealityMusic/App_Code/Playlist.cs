﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Playlist
/// </summary>
public class Playlist
{
    public int userid { get; set; }
    public String playlistName { get; set; }
    public int playlistID { get; set; }

    public Playlist(int userid, String playlistName, int playlistID)
    {
        this.userid = userid;
        this.playlistName = playlistName;
        this.playlistID = playlistID;
    }
}