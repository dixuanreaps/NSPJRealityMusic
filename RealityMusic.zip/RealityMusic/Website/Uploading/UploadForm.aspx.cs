﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using MySql.Data.MySqlClient;
using System.IO;
using nClam;
using System.Web.Configuration;
using System.Diagnostics;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using NAudio.Wave;
using System.Web.Services;

//if there is a virus in audio file, respective thumbnail will be deleted, but if there is a thumbnail with the same name, will overwrite and both gets deleted 

public partial class UploadForm : Page
{

    bool error;
    string date=DateTime.Now.ToString("d/MM/yyyy");
    static byte[] certM;
    static byte[] certI;
    byte[] bytescheckM;
    byte[] bytescheckI;
    static RSAParameters publicParams;
    Stopwatch stopwatch = new Stopwatch();
    int onLoad;
    int onSubmit;
    String username;
    int userid;

    protected void Page_Load(object sender, EventArgs e)
    {

        onLoad = DateTime.Now.Second;
        
        if (!IsPostBack)
        {
            TitleLbl.Visible = false;
            DescLbl.Visible = false;
            MusicLbl.Visible = false;
            ThumbLbl.Visible = false;
            //AudioVirus.Visible = false;
            //ImageVirus.Visible = false;
            typeLbl.Visible = false;
            s.Visible = false;
            spamLabel.Visible = false;
            spamBox.Visible = false;
            sql.Visible = false;
            checkSignM.Visible = false;
            //checkSignI.Visible = false;
        }
        
        if(IsPostBack && FileUpload1.HasFile)
        {
            checkSignM.Visible = true;
        }

        //if (IsPostBack && FileUpload2.HasFile)
        //{
            //checkSignI.Visible = true;
        //}

        // store the FileUpload object in Session. 
        // "FileUpload1" is the ID of your FileUpload control
        // This condition occurs for first time you upload a file
        //audio
        if (Session["audio"] == null && FileUpload1.HasFile)
        {
            Session["audio"] = FileUpload1;
            Label1.Text = FileUpload1.FileName; // get the name 
        }
        // This condition will occur on next postbacks        
        else if (Session["audio"] != null && (!FileUpload1.HasFile))
        {
            FileUpload1 = (FileUpload)Session["audio"];
        }
        //  when Session will have File but user want to change the file 
        // i.e. wants to upload a new file using same FileUpload control
        // so update the session to have the newly uploaded file
        else if (FileUpload1.HasFile)
        {
            Session["audio"] = FileUpload1;
            Label1.Text = FileUpload1.FileName;
        }

        ////image
        //if (Session["image"] == null && FileUpload2.HasFile)
        //{
        //    Session["image"] = FileUpload2;
        //    Label2.Text = FileUpload2.FileName; // get the name 
        //}
        //// This condition will occur on next postbacks        
        //else if (Session["image"] != null && (!FileUpload2.HasFile))
        //{
        //    FileUpload2 = (FileUpload)Session["image"];
        //}
        ////  when Session will have File but user want to change the file 
        //// i.e. wants to upload a new file using same FileUpload control
        //// so update the session to have the newly uploaded file
        //else if (FileUpload2.HasFile)
        //{
        //    Session["image"] = FileUpload2;
        //    Label2.Text = FileUpload2.FileName;
        //}
        username = (String)Session["username"];
        userid = (int)Session["userid"];
    }

    //once submit button is clicked
    protected void SubmitBtn_Click(object sender, EventArgs e)
    {
        
        string musicID = GenerateID();

        string title = TxtName.Text;
        string desc = TxtDesc.Text;

        HttpPostedFile postedFile = FileUpload1.PostedFile;
        HttpPostedFile postedFile2 = FileUpload2.PostedFile;

        string audioName = Path.GetFileName(postedFile.FileName);
        string imageName = Path.GetFileName(postedFile2.FileName);

        string audioExtension = Path.GetExtension(audioName);
        string imageExtension = Path.GetExtension(imageName);

        int audioSize = postedFile.ContentLength;
        int imgSize = postedFile2.ContentLength;

        string selectedType = Request.Form["Type"].ToString();

        //string UserID;

        //getting username of current session 
        MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;database=test; password=Devils8ats");
        //connection.Open();
        //string selectQuery = "SELECT UserID from users where UserID=@UserID";

        //using (MySqlCommand command = new MySqlCommand(selectQuery, connection))
        //{
        //    command.Parameters.AddWithValue("@UserID", "10");
        //    UserID = command.ExecuteScalar().ToString();
        //}
        
        //connection.Close();

        //validation
        if (TxtDesc.Text == "" || TxtDesc.Text == null)
        {
            error = true;
            DescLbl.Visible = true;
            DescLbl.Text = "Please fill in the description!";
            DescLbl.ForeColor = System.Drawing.Color.Red;
        }

        if (TxtName.Text == "" || TxtName.Text == null)
        {
            error = true;
            TitleLbl.Visible = true;
            TitleLbl.Text = "Please fill in the title!";
            TitleLbl.ForeColor = System.Drawing.Color.Red;
        }

        if (FileUpload1.HasFile == false)
        {
            error = true;
            MusicLbl.Visible = true;
            MusicLbl.Text = "Please choose an audio file to upload!";
            MusicLbl.ForeColor = System.Drawing.Color.Red;
        }

        else if (!audioExtension.ToLower().Equals(".mp3"))
        {
            error = true;
            MusicLbl.Visible = true;
            MusicLbl.Text = "Only mp3 audio files can be uploaded!";
            MusicLbl.ForeColor = System.Drawing.Color.Red;

        }

        if (FileUpload2.HasFile == false)
        {
            error = true;
            ThumbLbl.Visible = true;
            ThumbLbl.Text = "Please choose an image file to upload!";
            ThumbLbl.ForeColor = System.Drawing.Color.Red;
        }

        else if (!imageExtension.ToLower().Equals(".jpg"))
        {
            error = true;
            ThumbLbl.Visible = true;
            ThumbLbl.Text = "Only jpg files can be uploaded!";
            ThumbLbl.ForeColor = System.Drawing.Color.Red;
        }


        if (audioSize > 15000000) //15mb in bytes
        {
            error = true;
            MusicLbl.Visible = true;
            MusicLbl.Text = "Your audio file is too large! Please choose a file which is less than 15mb!";
            MusicLbl.ForeColor = System.Drawing.Color.Red;
        }

        if (imgSize > 10000000) //10mb in bytes
        {
            error = true;
            ThumbLbl.Visible = true;
            ThumbLbl.Text = "Your image file is too large! Please choose a file which is less than 10mb!";
            ThumbLbl.ForeColor = System.Drawing.Color.Red;
        }

        //if (selectedType == "" || selectedType == null)
        //    {
        //        error = true;
        //        typeLbl.Visible = true;
        //        typeLbl.Text = "Select a price type for your music!";
        //        typeLbl.ForeColor = System.Drawing.Color.Red;
        //    }


        if (spamBox.Text.Equals("") || spamBox.Text.Equals(null))
        {
            
        }
        else
        {
            error = true;
            Response.Redirect("UploadForm.aspx");
        }

        if (error == false) //if no errors, save files to server and then upload to database
        {
            onSubmit = DateTime.Now.Second;

            //saving files to folder in server
            string audioLocation = Server.MapPath("..\\..\\Data\\Audio") + "\\" + musicID + ".mp3";
            string imageLocation = Server.MapPath("..\\..\\Data\\Thumbnail") + "\\" + userid + "_" + title + ".jpg";
            audioLocation = audioLocation.Replace(@"\", @"\\");
            imageLocation = imageLocation.Replace(@"\", @"\\");

            if (FileUpload1.HasFile)
            {
                FileUpload1.PostedFile.SaveAs(audioLocation);
            }

            if (FileUpload2.HasFile)
            {

                FileUpload2.PostedFile.SaveAs(imageLocation);
            }

            //calling clamclient to scan files in server
            var clam = new ClamClient("localhost", 3310);
            if (audioExtension.ToLower() == ".mp3")  //no errors in extensions, then scan uploaded files
            {
                var scanResult1 = clam.ScanFileOnServer(audioLocation);
                //scanning (audio)
                switch (scanResult1.Result)
                {
                    case ClamScanResults.Clean:
                        error = false;
                        // AudioVirus.Visible = true;
                        // AudioVirus.Text = "Clean!";
                        break;
                    case ClamScanResults.VirusDetected:
                        error = true;
                        // AudioVirus.Visible = true;
                        // AudioVirus.Text = "Virus Found!";
                        System.IO.File.Delete(audioLocation); //deleting audio file if virus is found
                        //AudioVirus.Text = "Virus name: {0}", scanResult1.InfectedFiles.First().VirusName) ;
                        System.IO.File.Delete(imageLocation);
                        Response.Redirect("UnsuccessfulUpload.aspx");
                        break;
                    case ClamScanResults.Error:
                        error = true;
                        // AudioVirus.Visible = true;
                        //AudioVirus.Text = "Woah an error occured! Error: {0}"; scanResult1.RawResult);
                        //AudioVirus.Text = "Error!";
                        break;
                }
            }

            if (imageExtension.ToLower() == ".jpg")
            {
                var scanResult2 = clam.ScanFileOnServer(imageLocation);

                //scanning (image)
                switch (scanResult2.Result)
                {
                    case ClamScanResults.Clean:
                        error = false;
                        //ImageVirus.Visible = true;
                        // ImageVirus.Text = "Clean!";
                        break;
                    case ClamScanResults.VirusDetected:
                        error = true;
                        //ImageVirus.Visible = true;
                        //ImageVirus.Text = "Virus Found!";
                        System.IO.File.Delete(imageLocation); //deleting image file if virus is found
                        //ImageVirus.Text = "Virus name: {0}", scanResult2.InfectedFiles.First().VirusName);
                        System.IO.File.Delete(audioLocation);
                        Response.Redirect("UnsuccessfulUpload.aspx");
                        break;
                    case ClamScanResults.Error:
                        error = true;
                        //ImageVirus.Visible = true;
                        //ImageVirus.Text = "Woah an error occured! Error: {0}"; scanResult2.RawResult);
                        //ImageVirus.Text = "Error!";
                        break;
                }
            }

            ////audio
            //Stream stream = postedFile.InputStream;
            //BinaryReader binaryReader = new BinaryReader(stream);
            //byte[] bytes = binaryReader.ReadBytes((int)stream.Length);

            ////image
            //Stream stream2 = postedFile2.InputStream;
            //BinaryReader binaryReader2 = new BinaryReader(stream2);
            //byte[] bytes2 = binaryReader2.ReadBytes((int)stream2.Length);

            RSACryptoServiceProvider rsaWrite = new RSACryptoServiceProvider();
            rsaWrite.ImportParameters(publicParams);

            byte[] bytesofMusic = FileUpload1.FileBytes;
            //byte[] bytesofPic = FileUpload2.FileBytes;

            //cutting smaller byte array music
            bytescheckM = new byte[64];
            Array.Copy(bytesofMusic, bytescheckM, bytescheckM.Length);
            //cutting smaller byte array image
            //bytescheckI = new byte[64];
            //Array.Copy(bytesofPic, bytescheckI, bytescheckI.Length);

            //creating signatures
            //byte[] ConfirmM = rsaWrite.SignData(bytescheckM, new SHA1CryptoServiceProvider());
            //byte[] ConfirmI = rsaWrite.SignData(bytescheckI, new SHA1CryptoServiceProvider());
            
            //comparing Signatures
            //bool MEqual = ConfirmM.SequenceEqual(certM);
            //bool IEqual = ConfirmI.SequenceEqual(certI);
            
            //validating signatures
            String validatedMusic = validate(bytescheckM, rsaWrite.ExportParameters(false), certM);
            //String validatedImage = validate(bytescheckI, rsaWrite.ExportParameters(false), ConfirmI);
            MessageBox.Show(validatedMusic);
            //MessageBox.Show(validatedImage);
            if (validatedMusic == "Verified!")
            {

                String encrypted = Server.MapPath("..\\..\\Data\\Audio\\Encrypted") + "\\" + musicID + ".mp3";
                EncryptFile(audioLocation, encrypted, "601f1889667efaebb33b8c12572835da3f027f78");

                File.Delete(audioLocation);

                //putting data to mysql database

                connection.Open();
                string insertQuery = "INSERT INTO test.music (MusicID,UserID,MusicTitle,Description,AudioPath,ImagePath,PriceType,UploadDate,Views,Likes,NoOfReports) VALUES (@MusicID,@UserID,@MusicTitle,@Description,@AudioPath,@ImagePath,@PriceType,@UploadDate,@Views,@Likes,@NoOfReports)"; //nameofDB.nameofTable


                using (MySqlCommand command = new MySqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@MusicID", musicID);
                    command.Parameters.AddWithValue("@UserID", userid);
                    command.Parameters.AddWithValue("@MusicTitle", title);
                    command.Parameters.AddWithValue("@Description", desc);
                    command.Parameters.AddWithValue("@AudioPath", ("Data\\Audio\\Encrypted") + "\\" + musicID + ".mp3");
                    command.Parameters.AddWithValue("@ImagePath", ("Data\\Thumbnail") + "\\" + "heyka" + "_" + title + ".jpg");
                    command.Parameters.AddWithValue("@PriceType", selectedType);
                    command.Parameters.AddWithValue("@UploadDate", date);
                    command.Parameters.AddWithValue("@Views", 0);
                    command.Parameters.AddWithValue("@Likes", 0);
                    command.Parameters.AddWithValue("@NoOfReports", 0);
                    //command.Parameters.AddWithValue("@OnLoadTime", onLoad);
                    //command.Parameters.AddWithValue("@SubmitTime", onSubmit);

                    int result = command.ExecuteNonQuery();

                    if (result < 0)
                        sql.Visible = true;
                    sql.Text = ("Error inserting data into Database!");
                }

                connection.Close();
                Response.Redirect("SuccessfulUpload.aspx?musicid=" + musicID);
            }
            else
            {
                File.Delete(audioLocation);
                File.Delete(imageLocation);
                Response.Redirect("UnsuccessfulValidation.aspx");
            }
        }
    }

    //Symmetric Encryption of File
    //InputFile(decrypted) and OutputFile(Encrypted) are paths
    private void EncryptFile(string inputFile, string outputFile, string key)
    {
        try
        {
            byte[] keyBytes;
            keyBytes = Encoding.Unicode.GetBytes(key);

            Rfc2898DeriveBytes derivedKey = new Rfc2898DeriveBytes(key, keyBytes);

            RijndaelManaged rijndaelCSP = new RijndaelManaged();
            rijndaelCSP.Padding = PaddingMode.ANSIX923;
            rijndaelCSP.Key = derivedKey.GetBytes(rijndaelCSP.KeySize / 8);
            rijndaelCSP.IV = derivedKey.GetBytes(rijndaelCSP.BlockSize / 8);

            ICryptoTransform encryptor = rijndaelCSP.CreateEncryptor();

            FileStream inputFileStream = new FileStream(inputFile, FileMode.Open, FileAccess.Read);

            byte[] inputFileData = new byte[(int)inputFileStream.Length];
            inputFileStream.Read(inputFileData, 0, (int)inputFileStream.Length);

            FileStream outputFileStream = new FileStream(outputFile, FileMode.Create, FileAccess.Write);

            CryptoStream encryptStream = new CryptoStream(outputFileStream, encryptor, CryptoStreamMode.Write);
            encryptStream.Write(inputFileData, 0, (int)inputFileStream.Length);
            encryptStream.FlushFinalBlock();

            rijndaelCSP.Clear();
            encryptStream.Close();
            inputFileStream.Close();
            outputFileStream.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Encryption Failed!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        //MessageBox.Show("File Encryption Complete!");

    }

    //authenticate for server
    public String validate(byte[] arrayvalue, RSAParameters Public, Byte[] Signature)
    {

        var rsaRead = new RSACryptoServiceProvider();
        rsaRead.ImportParameters(Public);

        if (rsaRead.VerifyData(arrayvalue,
                               new SHA1CryptoServiceProvider(),
                               Signature))
        {
            return "Verified!";
        }
        else
        {
            return "NOT verified!";
        }
    }

    protected void CancelBtn_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/UploadForm.aspx", true);
    }

    public string GenerateID() 
    {
        return Guid.NewGuid().ToString("N");
    }

    //Fileupload1 for music
    public void Filechooser(object sender, EventArgs e)
    {
            RSACryptoServiceProvider rsaWrite = new RSACryptoServiceProvider();
            publicParams = rsaWrite.ExportParameters(false);
        
            byte[] bytesofMusic = FileUpload1.FileBytes;

            bytescheckM = new byte[64];
            Array.Copy(bytesofMusic, bytescheckM, bytescheckM.Length);

            certM = rsaWrite.SignData(bytescheckM, new SHA1CryptoServiceProvider());
        
    }

    ////Fileupload2 for image
    //public void Filechooser2(object sender, EventArgs e)
    //{
    //        RSACryptoServiceProvider rsaWrite = new RSACryptoServiceProvider();
    //        publicParams = rsaWrite.ExportParameters(false);
       
    //        byte[] bytesofPic = FileUpload2.FileBytes;

    //        bytescheckI = new byte[64];
    //        Array.Copy(bytesofPic, bytescheckI, bytescheckI.Length);

    //        certI = rsaWrite.SignData(bytescheckI, new SHA1CryptoServiceProvider());
    //}

    //check Music genuine
    protected void checkSignM_Click(object sender, EventArgs e)
    {

        byte[] bytesofMusic = FileUpload1.FileBytes;

        bytescheckM = new byte[64];
        Array.Copy(bytesofMusic, bytescheckM, bytescheckM.Length);

        var rsaRead = new RSACryptoServiceProvider();
        rsaRead.ImportParameters(publicParams);

        if (rsaRead.VerifyData(bytescheckM,
                               new SHA1CryptoServiceProvider(),
                               certM))
        {
            Label3.Text = "Verified!";
        }
        else
        {
            Label3.Text = "NOT verified!";
        }
    }

    ////check image genuine
    //protected void checkSignI_Click(object sender, EventArgs e)
    //{
    //    byte[] bytesofPic = FileUpload2.FileBytes;

    //    bytescheckI = new byte[64];
    //    Array.Copy(bytesofPic, bytescheckI, bytescheckI.Length);

    //    var rsaRead = new RSACryptoServiceProvider();
    //    rsaRead.ImportParameters(publicParams);

    //    if (rsaRead.VerifyData(bytescheckI,
    //                           new SHA1CryptoServiceProvider(),
    //                           certI))
    //    {
    //        Label4.Text = "Verified!";
    //    }
    //    else
    //    {
    //        Label4.Text= "NOT verified!";
    //    }
    //}
}