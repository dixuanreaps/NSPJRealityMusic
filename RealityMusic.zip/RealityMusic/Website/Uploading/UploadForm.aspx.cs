﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using MySql.Data.MySqlClient;
using System.IO;
using nClam;
using System.Web.Configuration;
using System.Diagnostics;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using NAudio.Wave;
using System.Web.Services;

//if there is a virus in audio file, respective thumbnail will be deleted, but if there is a thumbnail with the same name, will overwrite and both gets deleted 

public partial class UploadForm : Page
{

    bool error;
    string date=DateTime.Now.ToString("d/MM/yyyy");
    static byte[] certM;
    static byte[] certI;
    byte[] bytescheckM;
    byte[] bytescheckI;
    static RSAParameters publicParams;
    String username;
    int userid;
    String musicTitleDB, descDB, priceTypeDB;
    int ans;
    string hash;
    String userbirthdate;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            TitleLbl.Visible = false;
            DescLbl.Visible = false;
            MusicLbl.Visible = false;
            ThumbLbl.Visible = false;
            //AudioVirus.Visible = false;
            //ImageVirus.Visible = false;
            typeLbl.Visible = false;
            sql.Visible = false;
            checkSignM.Visible = false;
            //checkSignI.Visible = false;
            ansLbl.Visible = false;
        }
        
        if(IsPostBack && FileUpload1.HasFile)
        {
            checkSignM.Visible = true;
        }

        //if (IsPostBack && FileUpload2.HasFile)
        //{
            //checkSignI.Visible = true;
        //}

        // store the FileUpload object in Session. 
        // "FileUpload1" is the ID of your FileUpload control
        // This condition occurs for first time you upload a file
        //audio
        if (Session["audio"] == null && FileUpload1.HasFile)
        {
            Session["audio"] = FileUpload1;
            Label1.Text = FileUpload1.FileName; // get the name 
        }
        // This condition will occur on next postbacks        
        else if (Session["audio"] != null && (!FileUpload1.HasFile))
        {
            FileUpload1 = (FileUpload)Session["audio"];
        }
        //  when Session will have File but user want to change the file 
        // i.e. wants to upload a new file using same FileUpload control
        // so update the session to have the newly uploaded file
        else if (FileUpload1.HasFile)
        {
            Session["audio"] = FileUpload1;
            Label1.Text = FileUpload1.FileName;
        }

        ////image
        if (Session["image"] == null && FileUpload2.HasFile)
        {
            Session["image"] = FileUpload2;
            
            Label2.Text = FileUpload2.FileName; // get the name 
        }
        // This condition will occur on next postbacks        
        else if (Session["image"] != null && (!FileUpload2.HasFile))
        {
            FileUpload2 = (FileUpload)Session["image"];
        }
        //  when Session will have File but user want to change the file 
        // i.e. wants to upload a new file using same FileUpload control
        // so update the session to have the newly uploaded file
        else if (FileUpload2.HasFile)
        {
            Session["image"] = FileUpload2;
            Label2.Text = FileUpload2.FileName;
        }
        username = (String)Session["username"];
        userid = (int)Session["userid"];

        if (Session["Result"] != null)
        {
            ans = (int)Session["Result"];
        }
        var r = new Random();
        var a = r.Next(10);
        var b = r.Next(10);
        Session["FirstNumber"] = a;
        Session["SecondNumber"] = b;
        Session["Result"] = a + b;
        Label4.Text = a.ToString();
        Label5.Text = b.ToString();
        

    }

    //once submit button is clicked
    protected void SubmitBtn_Click(object sender, EventArgs e)
    {
        
        string musicID = GenerateID().Substring(0,7);

        string title = TxtName.Text;
        string desc = TxtDesc.Text;

        HttpPostedFile postedFile = FileUpload1.PostedFile;
        HttpPostedFile postedFile2 = FileUpload2.PostedFile;

        string audioName = Path.GetFileName(postedFile.FileName);
        string imageName = Path.GetFileName(postedFile2.FileName);

        string audioExtension = Path.GetExtension(audioName);
        string imageExtension = Path.GetExtension(imageName);

        int audioSize = postedFile.ContentLength;
        int imgSize = postedFile2.ContentLength;

        string selectedType = Request.Form["Type"].ToString();



        //validation
        if (TxtDesc.Text == "" || TxtDesc.Text == null)
        {
            error = true;
            DescLbl.Visible = true;
            DescLbl.Text = "Please fill in the description!";
            DescLbl.ForeColor = System.Drawing.Color.Red;
        }
        else
        {
            DescLbl.Visible = false;
        }

        if (TxtName.Text == "" || TxtName.Text == null)
        {
            error = true;
            TitleLbl.Visible = true;
            TitleLbl.Text = "Please fill in the title!";
            TitleLbl.ForeColor = System.Drawing.Color.Red;
        }
        else
        {
            TitleLbl.Visible = false;
        }

        if (FileUpload1.HasFile == false)
        {
            error = true;
            MusicLbl.Visible = true;
            MusicLbl.Text = "Please choose an audio file to upload!";
            MusicLbl.ForeColor = System.Drawing.Color.Red;
        }

        //accepted multiple extensions for image and audio files 
        else if (!audioExtension.ToLower().Equals(".mp3") && !audioExtension.ToLower().Equals(".wav") && !audioExtension.ToLower().Equals(".ogg") && !audioExtension.ToLower().Equals(".oga") && !audioExtension.ToLower().Equals(".m4a") && !audioExtension.ToLower().Equals(".mp4") && !audioExtension.ToLower().Equals(".flac"))
        {
            error = true;
            MusicLbl.Visible = true;
            MusicLbl.Text = "Sorry, we only support MP3, WAV, OGG, OGA, M4A, MP4, FLAC files.";
            MusicLbl.ForeColor = System.Drawing.Color.Red;

        }
        else
        {
            MusicLbl.Visible = false;
        }

        if (FileUpload2.HasFile == false)
        {
            error = true;
            ThumbLbl.Visible = true;
            ThumbLbl.Text = "Please choose an image file to upload!";
            ThumbLbl.ForeColor = System.Drawing.Color.Red;
        }

        else if (!imageExtension.ToLower().Equals(".jpg") && !imageExtension.ToLower().Equals(".tif") && !imageExtension.ToLower().Equals(".tiff") && !imageExtension.ToLower().Equals(".gif") && !imageExtension.ToLower().Equals(".png") && !imageExtension.ToLower().Equals(".bmp"))
        {
            error = true;
            ThumbLbl.Visible = true;
            ThumbLbl.Text = "Sorry we only support JPG, TIF, GIF, BMP or PNG files!";
            ThumbLbl.ForeColor = System.Drawing.Color.Red;
        }
        else
        {
            ThumbLbl.Visible = false;
        }


        if (audioSize > 1073741824) //1gb in bytes
        {
            error = true;
            MusicLbl.Visible = true;
            MusicLbl.Text = "Your audio file is too large! Please choose a file which is less than 1GB!";
            MusicLbl.ForeColor = System.Drawing.Color.Red;
        }
        else
        {
            MusicLbl.Visible = false;
        }

        if (imgSize > 524288000) //500mb in bytes
        {
            error = true;
            ThumbLbl.Visible = true;
            ThumbLbl.Text = "Your image file is too large! Please choose a file which is less than 500MB!";
            ThumbLbl.ForeColor = System.Drawing.Color.Red;
        }
        else
        {
            ThumbLbl.Visible = false;
        }

        //if (selectedType == "" || selectedType == null)
        //    {
        //        error = true;
        //        typeLbl.Visible = true;
        //        typeLbl.Text = "Select a price type for your music!";
        //        typeLbl.ForeColor = System.Drawing.Color.Red;
        //    }

        if (answerBox.Text == null || answerBox.Text == "")
        {
            ansLbl.Visible = true;
            ansLbl.Text = "Please fill in the answer!";
            ansLbl.ForeColor = System.Drawing.Color.Red;
        }
        else if (answerBox.Text != ans.ToString())
        {
            error = true;
            ansLbl.Visible = true;
            ansLbl.Text = "Wrong answer!";
            ansLbl.ForeColor = System.Drawing.Color.Red;
        }
        else
        {
            ansLbl.Visible = false;
        }

        //checking for duplicate data
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString; //database connection string (linked to web config)
        MySqlDataReader reader;

        using (MySqlConnection con = new MySqlConnection(cs))
        {
            con.Open();
            string selectQuery = "SELECT userID,description,musicTitle,priceType FROM music where userID=@userID";
            MySqlCommand cmd = new MySqlCommand(selectQuery, con);
            cmd.Parameters.AddWithValue("@userID", userid);
            reader = cmd.ExecuteReader();
            while (reader.HasRows && reader.Read())
            {
                descDB = reader.GetString(reader.GetOrdinal("description"));
                musicTitleDB = reader.GetString(reader.GetOrdinal("musicTitle"));
                priceTypeDB = reader.GetString(reader.GetOrdinal("priceType"));


            }
            if (musicTitleDB != null && descDB != null && priceTypeDB != null)

            {
                if (musicTitleDB.Equals(title) && descDB.Equals(desc) && priceTypeDB.Equals(selectedType))
                {
                    error = true;
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Error due to duplicate data!" + "');", true);
                }
            }
            con.Close();
        }  //check for duplicate end


        if (error == false) //if no errors, save files to server and then upload to database
        {
           
            //saving files to folder in server
            string audioLocation = Server.MapPath("..\\..\\Data\\Audio") + "\\" + musicID + audioExtension;
            string imageLocation = Server.MapPath("..\\..\\Data\\Thumbnail") + "\\" + userid + "_" + title + imageExtension;
            audioLocation = audioLocation.Replace(@"\", @"\\");
            imageLocation = imageLocation.Replace(@"\", @"\\");

            if (FileUpload1.HasFile)
            {
                FileUpload1.PostedFile.SaveAs(audioLocation);
            }

            if (FileUpload2.HasFile)
            {

                FileUpload2.PostedFile.SaveAs(imageLocation);
            }

            //calling clamclient to scan files in server
            var clam = new ClamClient("localhost", 3310);
            
                var scanResult1 = clam.ScanFileOnServer(audioLocation);
                //scanning (audio)
                switch (scanResult1.Result)
                {
                    case ClamScanResults.Clean:
                        error = false;
                        // AudioVirus.Visible = true;
                        // AudioVirus.Text = "Clean!";
                        break;
                    case ClamScanResults.VirusDetected:
                        error = true;
                        // AudioVirus.Visible = true;
                        // AudioVirus.Text = "Virus Found!";
                        System.IO.File.Delete(audioLocation); //deleting audio file if virus is found
                        //AudioVirus.Text = "Virus name: {0}", scanResult1.InfectedFiles.First().VirusName) ;
                        System.IO.File.Delete(imageLocation);
                        Response.Redirect("UnsuccessfulUpload.aspx");
                        break;
                    case ClamScanResults.Error:
                        error = true;
                        // AudioVirus.Visible = true;
                        //AudioVirus.Text = "Woah an error occured! Error: {0}"; scanResult1.RawResult);
                        //AudioVirus.Text = "Error!";
                        break;
                }
            

            
                var scanResult2 = clam.ScanFileOnServer(imageLocation);

                //scanning (image)
                switch (scanResult2.Result)
                {
                    case ClamScanResults.Clean:
                        error = false;
                        //ImageVirus.Visible = true;
                        // ImageVirus.Text = "Clean!";
                        break;
                    case ClamScanResults.VirusDetected:
                        error = true;
                        //ImageVirus.Visible = true;
                        //ImageVirus.Text = "Virus Found!";
                        System.IO.File.Delete(imageLocation); //deleting image file if virus is found
                        //ImageVirus.Text = "Virus name: {0}", scanResult2.InfectedFiles.First().VirusName);
                        System.IO.File.Delete(audioLocation);
                        Response.Redirect("UnsuccessfulUpload.aspx");
                        break;
                    case ClamScanResults.Error:
                        error = true;
                        //ImageVirus.Visible = true;
                        //ImageVirus.Text = "Woah an error occured! Error: {0}"; scanResult2.RawResult);
                        //ImageVirus.Text = "Error!";
                        break;
                }

            //changing audio extension to mp3
            //File.Move(audioLocation, Path.ChangeExtension(audioLocation, ".mp3"));

            ////audio
            //Stream stream = postedFile.InputStream;
            //BinaryReader binaryReader = new BinaryReader(stream);
            //byte[] bytes = binaryReader.ReadBytes((int)stream.Length);

            ////image
            //Stream stream2 = postedFile2.InputStream;
            //BinaryReader binaryReader2 = new BinaryReader(stream2);
            //byte[] bytes2 = binaryReader2.ReadBytes((int)stream2.Length);

            RSACryptoServiceProvider rsaWrite = new RSACryptoServiceProvider();
            rsaWrite.ImportParameters(publicParams);

            byte[] bytesofMusic = FileUpload1.FileBytes;
            //byte[] bytesofPic = FileUpload2.FileBytes;

            //cutting smaller byte array music
            bytescheckM = new byte[64];
            Array.Copy(bytesofMusic, bytescheckM, bytescheckM.Length);
            //cutting smaller byte array image
            //bytescheckI = new byte[64];
            //Array.Copy(bytesofPic, bytescheckI, bytescheckI.Length);

            //creating signatures
            //byte[] ConfirmM = rsaWrite.SignData(bytescheckM, new SHA1CryptoServiceProvider());
            //byte[] ConfirmI = rsaWrite.SignData(bytescheckI, new SHA1CryptoServiceProvider());
            
            //comparing Signatures
            //bool MEqual = ConfirmM.SequenceEqual(certM);
            //bool IEqual = ConfirmI.SequenceEqual(certI);
            
            //validating signatures
            String validatedMusic = validate(bytescheckM, rsaWrite.ExportParameters(false), certM);
            //String validatedImage = validate(bytescheckI, rsaWrite.ExportParameters(false), ConfirmI);
            
            //MessageBox.Show(validatedMusic);
            //MessageBox.Show(validatedImage);
            if (validatedMusic == "Verified!")
            {
                
                using (MySqlConnection con = new MySqlConnection(cs))
                {
                    con.Open();
                    string selectQuery = "SELECT birthdate FROM useraccount WHERE userID = @userID";
                    MySqlCommand cmd = new MySqlCommand(selectQuery, con);
                    cmd.Parameters.AddWithValue("@userID", userid);
                    reader = cmd.ExecuteReader();
                    while (reader.HasRows && reader.Read())
                    {
                        userbirthdate = reader.GetString(reader.GetOrdinal("birthdate"));
                        //MessageBox.Show(userbirthdate);
                    }
                    
                    con.Close();
                } 

                String encrypted = Server.MapPath("..\\..\\Data\\Audio\\Encrypted") + "\\" + musicID + audioExtension;
                EncryptFile(audioLocation, encrypted, Hash(userbirthdate));

                File.Delete(audioLocation);

                //putting data to mysql database
                using (MySqlConnection con = new MySqlConnection(cs))
                {
                    con.Open();
                    string insertQuery = "INSERT INTO music (audioID,UserID,MusicTitle,Description,AudioPath,ImagePath,PriceType,UploadDate,Views,Likes,NoOfReports,username) VALUES (@audioID,@UserID,@MusicTitle,@Description,@AudioPath,@ImagePath,@PriceType,@UploadDate,@Views,@Likes,@NoOfReports,@username)";
                    MySqlCommand command = new MySqlCommand(insertQuery, con);

                    command.Parameters.AddWithValue("@audioID", musicID);
                    command.Parameters.AddWithValue("@UserID", userid);
                    command.Parameters.AddWithValue("@MusicTitle", title);
                    command.Parameters.AddWithValue("@Description", desc);
                    command.Parameters.AddWithValue("@AudioPath", ("Data\\Audio\\Encrypted") + "\\" + musicID + audioExtension);
                    command.Parameters.AddWithValue("@ImagePath", ("Data\\Thumbnail") + "\\" + userid + "_" + title + imageExtension);
                    command.Parameters.AddWithValue("@PriceType", selectedType);
                    command.Parameters.AddWithValue("@UploadDate", date);
                    command.Parameters.AddWithValue("@Views", 0);
                    command.Parameters.AddWithValue("@Likes", 0);
                    command.Parameters.AddWithValue("@NoOfReports", 0);
                    command.Parameters.AddWithValue("@username", username);
                    //command.Parameters.AddWithValue("@OnLoadTime", onLoad);
                    //command.Parameters.AddWithValue("@SubmitTime", onSubmit);

                    int result = command.ExecuteNonQuery();

                    if (result < 0)
                        sql.Visible = true;
                    sql.Text = ("Error inserting data into Database!");


                    con.Close();
                }
                Response.Redirect("SuccessfulUpload.aspx?musicid=" + musicID);
            }
            else
            {
                File.Delete(audioLocation);
                File.Delete(imageLocation);
                Response.Redirect("UnsuccessfulValidation.aspx");
            }
        }
    }

    //Symmetric Encryption of File
    //InputFile(decrypted) and OutputFile(Encrypted) are paths
    private void EncryptFile(string inputFile, string outputFile, string key)
    {
        try
        {
            byte[] keyBytes;
            keyBytes = Encoding.Unicode.GetBytes(key);

            Rfc2898DeriveBytes derivedKey = new Rfc2898DeriveBytes(key, keyBytes);

            RijndaelManaged rijndaelCSP = new RijndaelManaged();
            rijndaelCSP.Padding = PaddingMode.ANSIX923;
            rijndaelCSP.Key = derivedKey.GetBytes(rijndaelCSP.KeySize / 8);
            rijndaelCSP.IV = derivedKey.GetBytes(rijndaelCSP.BlockSize / 8);

            ICryptoTransform encryptor = rijndaelCSP.CreateEncryptor();

            FileStream inputFileStream = new FileStream(inputFile, FileMode.Open, FileAccess.Read);

            byte[] inputFileData = new byte[(int)inputFileStream.Length];
            inputFileStream.Read(inputFileData, 0, (int)inputFileStream.Length);

            FileStream outputFileStream = new FileStream(outputFile, FileMode.Create, FileAccess.Write);

            CryptoStream encryptStream = new CryptoStream(outputFileStream, encryptor, CryptoStreamMode.Write);
            encryptStream.Write(inputFileData, 0, (int)inputFileStream.Length);
            encryptStream.FlushFinalBlock();

            rijndaelCSP.Clear();
            encryptStream.Close();
            inputFileStream.Close();
            outputFileStream.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Encryption Failed!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
    }

    //authenticate for server
    public String validate(byte[] arrayvalue, RSAParameters Public, Byte[] Signature)
    {

        var rsaRead = new RSACryptoServiceProvider();
        rsaRead.ImportParameters(Public);

        if (rsaRead.VerifyData(arrayvalue,
                               new SHA1CryptoServiceProvider(),
                               Signature))
        {
            return "Verified!";
        }
        else
        {
            return "NOT verified!";
        }
    }

    protected void CancelBtn_Click(object sender, EventArgs e)
    {
        Response.Redirect("UploadForm.aspx", true);
    }

    public string GenerateID() 
    {
        return Guid.NewGuid().ToString("N");
    }

    //Fileupload1 for music
    public void Filechooser(object sender, EventArgs e)
    {
            RSACryptoServiceProvider rsaWrite = new RSACryptoServiceProvider();
            publicParams = rsaWrite.ExportParameters(false);
        
            byte[] bytesofMusic = FileUpload1.FileBytes;

            bytescheckM = new byte[64];
            Array.Copy(bytesofMusic, bytescheckM, bytescheckM.Length);

            certM = rsaWrite.SignData(bytescheckM, new SHA1CryptoServiceProvider());
        
    }

    ////Fileupload2 for image
    //public void Filechooser2(object sender, EventArgs e)
    //{
    //        RSACryptoServiceProvider rsaWrite = new RSACryptoServiceProvider();
    //        publicParams = rsaWrite.ExportParameters(false);
       
    //        byte[] bytesofPic = FileUpload2.FileBytes;

    //        bytescheckI = new byte[64];
    //        Array.Copy(bytesofPic, bytescheckI, bytescheckI.Length);

    //        certI = rsaWrite.SignData(bytescheckI, new SHA1CryptoServiceProvider());
    //}

    //check Music genuine
    protected void checkSignM_Click(object sender, EventArgs e)
    {

        byte[] bytesofMusic = FileUpload1.FileBytes;

        bytescheckM = new byte[64];
        Array.Copy(bytesofMusic, bytescheckM, bytescheckM.Length);

        var rsaRead = new RSACryptoServiceProvider();
        rsaRead.ImportParameters(publicParams);

        if (rsaRead.VerifyData(bytescheckM,
                               new SHA1CryptoServiceProvider(),
                               certM))
        {
            Label3.Text = "Verified!";
        }
        else
        {
            Label3.Text = "NOT verified!";
        }
    }

    ////check image genuine
    //protected void checkSignI_Click(object sender, EventArgs e)
    //{
    //    byte[] bytesofPic = FileUpload2.FileBytes;

    //    bytescheckI = new byte[64];
    //    Array.Copy(bytesofPic, bytescheckI, bytescheckI.Length);

    //    var rsaRead = new RSACryptoServiceProvider();
    //    rsaRead.ImportParameters(publicParams);

    //    if (rsaRead.VerifyData(bytescheckI,
    //                           new SHA1CryptoServiceProvider(),
    //                           certI))
    //    {
    //        Label4.Text = "Verified!";
    //    }
    //    else
    //    {
    //        Label4.Text= "NOT verified!";
    //    }
    //}

    static string Hash(string input)
    {
        using (SHA256Managed sha256 = new SHA256Managed())
        {
            var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
            var sb = new StringBuilder(hash.Length * 2);

            foreach (byte b in hash)
            {
                // can be "x2" if you want lowercase
                sb.Append(b.ToString("X2"));
            }

            return sb.ToString();
        }
    }
}