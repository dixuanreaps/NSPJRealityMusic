﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using nClam;


public partial class SuccessfulUpload : System.Web.UI.Page
{
    public string musicid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["musicid"] != null && Request.QueryString["musicid"] != "") ;
        {
           musicid = Request.QueryString["musicid"];
            
        }
    }
}