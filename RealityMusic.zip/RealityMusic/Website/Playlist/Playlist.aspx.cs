﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

public partial class Website_Playlist_Playlist : System.Web.UI.Page
{
    public List<playlistItems> searchPlaylistResultList;
    public string pListofItems;
    public user mainSingerdata;
    public List<music> musicList;
    public string musicListdata;
    public int index;
    int sessionUserid;
    public string playlistid;
    public string currentmusic;
    public string audioExtension;

    protected void Page_Load(object sender, EventArgs e)
    {
        
        playlistid = "";
        if (Request.QueryString["playlist"] != null && Request.QueryString["index"] != null)
        {
            sessionUserid = (int)Session["userid"];
            playlistid = Request.QueryString["playlist"];
            index = int.Parse(Request.QueryString["index"]);

            searchPlaylistResultList = SearchPlaylistdatabase(playlistid);
            musicList = Searchmusicdatabase();

            JavaScriptSerializer oSerializer = new JavaScriptSerializer();
            if (searchPlaylistResultList.Any())
            {
                music Cmusic;
                Cmusic = Searchdatabaseformusic(searchPlaylistResultList[index - 1].audioID);
                mainSingerdata = Searchdatabaseforuserdata(Cmusic.Userid.ToString());
                
                String encrypted = Server.MapPath("..\\..\\" + Cmusic.AudioPath);
                audioExtension = Path.GetExtension(encrypted);
                //decryption
                String decrypted = Server.MapPath("..\\..\\Data\\Audio\\Decrypted") + "\\" + Cmusic.Musicid + audioExtension;
                DecryptFile(encrypted, decrypted, Hash(mainSingerdata.birthdate));

                audioExtension = "\"" + audioExtension + "\"";
                currentmusic = oSerializer.Serialize(Cmusic);
                Label1.Text = Cmusic.MusicTitle;
                Label2.Text = Cmusic.Likes.ToString();
                Label3.Text = Cmusic.Views.ToString();
                Label4.Text = Cmusic.PriceType;
            }
            else
            {
                currentmusic = "\"null\"";
            }

            pListofItems = oSerializer.Serialize(searchPlaylistResultList);
            musicListdata = oSerializer.Serialize(musicList);
        }
    }

    //list of Playlist audio data
    public List<playlistItems> SearchPlaylistdatabase(String searchvalue)
    {
        List<playlistItems> al = new List<playlistItems>();

        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT p.userID, pl.audioID, p.playlistName, p.playlistID, pl.musicTitle FROM playlist p INNER JOIN playlistitems pl ON p.playlistID = pl.playlistID WHERE p.playlistID = @value AND userID = @userid";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@value", searchvalue);
            command.Parameters.AddWithValue("@userid", sessionUserid);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (searchvalue == null || searchvalue == "")
                    {
                        break;
                    }
                    else
                    {
                        al.Add(new playlistItems(reader.GetString(reader.GetOrdinal("audioID")), reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("playlistName")), reader.GetString(reader.GetOrdinal("playlistID")), reader.GetString(reader.GetOrdinal("musicTitle"))));
                    }
                }

                if (reader != null)
                    reader.Close();
            }

        }
        return al;
    }

    //list of music search data
    public List<music> Searchmusicdatabase()
    {
        List<music> al = new List<music>();

        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT music.* FROM music";
            MySqlCommand command = new MySqlCommand(query, con);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                   
                        al.Add(new music(reader.GetString(reader.GetOrdinal("audioID")), reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("username")), reader.GetString(reader.GetOrdinal("musicTitle")), reader.GetString(reader.GetOrdinal("description")), reader.GetString(reader.GetOrdinal("audioPath")), reader.GetString(reader.GetOrdinal("imagePath")), reader.GetString(reader.GetOrdinal("priceType")), reader.GetString(reader.GetOrdinal("uploadDate")), reader.GetInt32(reader.GetOrdinal("views")), reader.GetInt32(reader.GetOrdinal("likes")), reader.GetInt32(reader.GetOrdinal("noOfReports"))));
                    
                }

                if (reader != null)
                    reader.Close();
            }

        }
        return al;
    }

    //retrieve music table data
    public music Searchdatabaseformusic(String searchvalue)
    {
        //List<music> al = new List<music>();
        music currentmusic = null;
        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT music.* FROM music WHERE audioID = @search";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@search", searchvalue);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (searchvalue == null || searchvalue == "")
                    {
                        break;
                    }
                    else
                    {
                        currentmusic = new music(reader.GetString(reader.GetOrdinal("audioID")), reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("username")), reader.GetString(reader.GetOrdinal("musicTitle")), reader.GetString(reader.GetOrdinal("description")), reader.GetString(reader.GetOrdinal("audioPath")), reader.GetString(reader.GetOrdinal("imagePath")), reader.GetString(reader.GetOrdinal("priceType")), reader.GetString(reader.GetOrdinal("uploadDate")), reader.GetInt32(reader.GetOrdinal("views")), reader.GetInt32(reader.GetOrdinal("likes")), reader.GetInt32(reader.GetOrdinal("noOfReports")));
                    }
                }

                if (reader != null)
                    reader.Close();
            }

        }
        return currentmusic;
    }

    //retrieve username of the user that upload music
    //changes to be made
    public user Searchdatabaseforuserdata(String searchvalue)
    {
        user singer = null;
        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {
            con.Open();
            String query = "SELECT * FROM useraccount WHERE userID = @search";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@search", searchvalue);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (searchvalue == null || searchvalue == "")
                    {
                        break;
                    }
                    else
                    {
                        singer = new user(reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("email")), reader.GetString(reader.GetOrdinal("username")), reader.GetString(reader.GetOrdinal("phoneNumber")), reader.GetString(reader.GetOrdinal("firstName")), reader.GetString(reader.GetOrdinal("lastName")), reader.GetString(reader.GetOrdinal("country")), reader.GetString(reader.GetOrdinal("imagePath")), reader.GetString(reader.GetOrdinal("birthdate")));
                    }
                }

                if (reader != null)
                    reader.Close();
            }
        }
        return singer;
    }

    //Symmetric Decryption of File
    //InputFile(Encrypted) and OutputFile(Decrypted) are paths
    private void DecryptFile(string inputFile, string outputFile, string key)
    {
        try
        {
            byte[] keyBytes = Encoding.Unicode.GetBytes(key);

            Rfc2898DeriveBytes derivedKey = new Rfc2898DeriveBytes(key, keyBytes);

            RijndaelManaged rijndaelCSP = new RijndaelManaged();
            rijndaelCSP.Padding = PaddingMode.ANSIX923;
            rijndaelCSP.Key = derivedKey.GetBytes(rijndaelCSP.KeySize / 8);
            rijndaelCSP.IV = derivedKey.GetBytes(rijndaelCSP.BlockSize / 8);
            ICryptoTransform decryptor = rijndaelCSP.CreateDecryptor();

            FileStream inputFileStream = new FileStream(inputFile, FileMode.Open, FileAccess.Read);

            CryptoStream decryptStream = new CryptoStream(inputFileStream, decryptor, CryptoStreamMode.Read);

            byte[] inputFileData = new byte[(int)inputFileStream.Length];
            int data = decryptStream.Read(inputFileData, 0, (int)inputFileStream.Length);

            //int decrypt_length = decryptStream.Read(inputFileData, 0, (int)inputFileStream.Length);
            FileStream outputFileStream = new FileStream(outputFile, FileMode.Create, FileAccess.Write);
            outputFileStream.Write(inputFileData, 0, data);
            outputFileStream.Flush();

            rijndaelCSP.Clear();

            decryptStream.Close();
            inputFileStream.Close();
            outputFileStream.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Decryption Failed!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
    }

    //hash for birthdate
    static string Hash(string input)
    {
        using (SHA256Managed sha256 = new SHA256Managed())
        {
            var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
            var sb = new StringBuilder(hash.Length * 2);

            foreach (byte b in hash)
            {
                // can be "x2" if you want lowercase
                sb.Append(b.ToString("X2"));
            }

            return sb.ToString();
        }
    }
}