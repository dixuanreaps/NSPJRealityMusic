﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Website_Playlist_Playlist : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    //list of music search data
    //public List<music> Searchdatabase(String searchvalue)
    //{
    //    List<music> al = new List<music>();

    //    //sql connection, query values to database error need help
    //    // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
    //    string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
    //    using (MySqlConnection con = new MySqlConnection(cs))
    //    {

    //        con.Open();
    //        String query = "SELECT music.* FROM music WHERE MusicTitle LIKE @search";
    //        MySqlCommand command = new MySqlCommand(query, con);
    //        command.Parameters.AddWithValue("@search", "%" + searchvalue + "%");
    //        using (MySqlDataReader reader = command.ExecuteReader())
    //        {
    //            while (reader.Read())
    //            {
    //                if (searchvalue == null || searchvalue == "")
    //                {
    //                    break;
    //                }
    //                else
    //                {
    //                    al.Add(new music(reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetString(3), reader.GetString(4), reader.GetString(5), reader.GetString(6), reader.GetString(7), reader.GetInt32(8), reader.GetInt32(9), reader.GetInt32(10)));
    //                }
    //            }

    //            if (reader != null)
    //                reader.Close();
    //        }

    //    }
    //    return al;
    //}


}