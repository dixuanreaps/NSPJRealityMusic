﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

public partial class WebSite1_LogOut : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        FormsAuthentication.SignOut();
        Session.Abandon();

        // clear authentication cookie
        HttpCookie cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, "");
        cookie1.Expires = DateTime.Now.AddYears(-1);
        Response.Cookies.Add(cookie1);

        // clear session cookie (not necessary for your current problem but i would recommend you do it anyway)
        SessionStateSection sessionStateSection = (SessionStateSection)WebConfigurationManager.GetSection("system.web/sessionState");
        HttpCookie cookie2 = new HttpCookie(sessionStateSection.CookieName, "");
        cookie2.Expires = DateTime.Now.AddYears(-1);
        Response.Cookies.Add(cookie2);

        //string logOutStatus = "Good bye!";
        //ScriptManager.RegisterClientScriptBlock(this,this.GetType(), "alertMessage", "alert('" + logOutStatus + "');", true);
        
        Session.Clear();
        checkUsage();


        Response.Redirect("Login.aspx");
        //Response.Write("<script>alert('"+ logOutStatus + "')</script>");
    }

    protected virtual bool IsFileLocked(FileInfo file)
    {
        FileStream stream = null;

        try
        {
            stream = file.Open(FileMode.Open, FileAccess.Read, FileShare.None);
        }
        catch (IOException)
        {
            //the file is unavailable because it is:
            //still being written to
            //or being processed by another thread
            //or does not exist (has already been processed)
            return true;
        }
        finally
        {
            if (stream != null)
                stream.Close();
        }

        //file is not locked
        return false;
    }

    protected void checkUsage()
    {
        string[] filePaths = Directory.GetFiles(Server.MapPath("../../Data/Audio/Decrypted/"));
        foreach (string filePath in filePaths)
        {
            FileInfo file = new FileInfo(filePath);
            bool locked = IsFileLocked(file);
            if (locked)
            {
                MessageBox.Show("currentlyUsing");
            }
            else
            {
                File.Delete(filePath);
            }
        }
    }
}