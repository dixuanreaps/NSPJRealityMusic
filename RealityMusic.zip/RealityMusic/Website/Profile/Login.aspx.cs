﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Login : System.Web.UI.Page
{
    MySql.Data.MySqlClient.MySqlConnection conn;
    MySql.Data.MySqlClient.MySqlCommand cmd;
    MySql.Data.MySqlClient.MySqlDataReader reader;
    String queryStr;
    String name;


    protected void loginEvent(object sender, EventArgs e)
    {
        String connString = System.Configuration.ConfigurationManager.ConnectionStrings["test"].ToString();
        conn = new MySql.Data.MySqlClient.MySqlConnection(connString);
        conn.Open();
        queryStr = "";
        queryStr = "SELECT * FROM test.useraccount WHERE userName='" + userName.Text + "' AND password='" + password.Text + "'";

        cmd = new MySql.Data.MySqlClient.MySqlCommand(queryStr, conn);

        reader = cmd.ExecuteReader();
        name = "";
        while(reader.HasRows && reader.Read())
        {
            name = reader.GetString(reader.GetOrdinal("firstName")) + " " +
            reader.GetString(reader.GetOrdinal("lastName"));
                
        }

        if (reader.HasRows)
        {
            Session["username"] = reader.GetString(reader.GetOrdinal("userName"));
            Session["userid"] = reader.GetInt32(reader.GetOrdinal("userid"));
            Response.BufferOutput = true;
            FormsAuthentication.SetAuthCookie(name, false);
            Response.Redirect("~/Website/Profile/UserProfile.aspx", false);
        }
        else
        {
            string loginStatus = "invalid user!";
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + loginStatus + "');", true);
            userName.Text = string.Empty;
            password.Text = string.Empty;
        }

        reader.Close();
        conn.Close();
    }

 
}
    
