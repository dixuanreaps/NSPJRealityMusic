﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

public partial class UserProfile : System.Web.UI.Page
{
    public List<Playlist> searchPlaylistName;
    public string pListofItems;
    int sessionUserid;

    protected void Page_Load(object sender, EventArgs e)
    {

            sessionUserid = (int)Session["userid"];
            searchPlaylistName = SearchPlaylistdatabase();

            JavaScriptSerializer oSerializer = new JavaScriptSerializer();
            pListofItems = oSerializer.Serialize(searchPlaylistName);

    }

    //list of Playlist audio data
    public List<Playlist> SearchPlaylistdatabase()
    {
        List<Playlist> al = new List<Playlist>();

        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT * FROM playlist WHERE userID = @userid";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@userid", sessionUserid);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                        al.Add(new Playlist(reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("playlistName")),reader.GetInt32(reader.GetOrdinal("playlistID"))));
                }

                if (reader != null)
                    reader.Close();
            }

        }
        return al;
    }
}