﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserProfile : System.Web.UI.Page
{
    int userid;

    protected void Page_Load(object sender, EventArgs e)
    {
        userid = (int)Session["userid"];
        Error.Visible = false;
        success.Visible = false;
    }

    protected void playlistcreation(object sender, EventArgs e)
    {
        if (playlistTitle.Text == null || playlistTitle.Text == "")
        {
            Error.Text = "Text field is empty. Please key in your playlist Title";
            Error.ForeColor = System.Drawing.Color.Red;
            Error.Visible = true;
        }
        else
        {
            string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
            using (MySqlConnection con = new MySqlConnection(cs))
            {
                con.Open();
                String query;
                MySqlCommand command;
                List<Playlist> al = new List<Playlist>();

                query = "SELECT * FROM playlist WHERE userID = @userid AND playlistName = @playlistName";
                command = new MySqlCommand(query, con);
                command.Parameters.AddWithValue("@userid", userid);
                command.Parameters.AddWithValue("@playlistName", playlistTitle.Text);
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        al.Add(new Playlist(reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("playlistName")), reader.GetInt32(reader.GetOrdinal("playlistID"))));
                    }

                    if (reader != null)
                        reader.Close();
                }
                if (al.Any())
                {
                    Error.Text = "PlayList name already Exists";
                    Error.ForeColor = System.Drawing.Color.Red;
                    Error.Visible = true;
                }
                else
                {
                    query = "INSERT INTO playlist (userID,playlistName) VALUES (@userID,@playlistName)";
                    command = new MySqlCommand(query, con);
                    command.Parameters.AddWithValue("@userID", userid);
                    command.Parameters.AddWithValue("@playlistName", playlistTitle.Text);
                    command.ExecuteNonQuery();

                    con.Close();
                    success.Text = "Successful";
                    success.ForeColor = System.Drawing.Color.ForestGreen;
                    success.Visible = true;
                }
            }
        }
    }
}