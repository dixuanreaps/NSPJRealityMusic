﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Net;
using System.Configuration;

public partial class Registration2 : System.Web.UI.Page
{
    MySql.Data.MySqlClient.MySqlConnection conn;
    MySql.Data.MySqlClient.MySqlCommand cmd;
   
    String queryStr;

    MySql.Data.MySqlClient.MySqlDataReader reader;
    string Email, Username, Firstname, Lastname, Password, Fullname;
    

    protected void Page_Load(object sender, EventArgs e)
    {
        string text = (Guid.NewGuid().ToString()).Substring(0, 5);
        Response.Cookies["Captcha"]["value"] = text;
        imageCaptcha.ImageUrl = "TestCaptcha.aspx";
        lblCaptcha.Visible = false;

        if (txtCaptcha.Text.ToString() == Request.Cookies["Captcha"]["value"])
        {
            lblCaptcha.Text = "This is correct";

        }
        else
        {
            lblCaptcha.Text = "This is incorrect";
            lblCaptcha.Visible = false;
        }
    }


    protected void lbCaptcha_Click(object sender, EventArgs e)
    {
        //only can refresh if fields above are all filled (for now)
        Response.Cookies["Captcha"]["value"] = (Guid.NewGuid().ToString()).Substring(0, 5);
        imageCaptcha.ImageUrl = "TestCaptcha.aspx";
    }

    protected void btnCaptcha_Click(object sender, EventArgs e)
    {
        if (txtCaptcha.Text.ToString() == Request.Cookies["Captcha"]["value"])
        {
            lblCaptcha.Text = "This is correct";
        }
        else
        {
            lblCaptcha.Text = "This is incorrect";
            lblCaptcha.Visible = false;
        }
    }


    private int numberPass(string pass)
    {
        int num = 0;

        foreach (char ch in pass)
        {
            if (char.IsDigit(ch))
            {
                num++;
            }
        }
        return num;
    }

    private int upperCase(string pass)
    {
        int num = 0;

        foreach (char ch in pass)
        {
            if (char.IsUpper(ch))
            {
                num++;
            }
        }
        return num;
    }

    protected void registerEventMethod(object sender, EventArgs e)
    {

        const int MIN_LENGTH = 8;

        string Username = userName.Text;
        string Password = password.Text;

        //string passwordBad = "password is weak! Your password must be at least 8 characters containing at least one upper case letter and one number!";
        string successReg = "registration successful! please proceed to log in!";
        
        if (Password.Length >= MIN_LENGTH && numberPass(Password) >= 1 
            && upperCase(Password) >= 1)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + successReg + "');", true);
            registerUser();
            Response.Redirect("Login.aspx");

            //if (txtCaptcha.Text.ToString() == Request.Cookies["Captcha"]["value"])
            //{
            //    lblCaptcha.Text = "This is correct";

            //}
            //else
            //{
            //    lblCaptcha.Text = "This is incorrect";
            //    lblCaptcha.Visible = false;
            //}
        } 
        else
        {
            lblValidatePassword.Text = "*Your password must be at least 8 characters containing at least one upper case letter and one number.";
            lblValidatePassword.ForeColor = System.Drawing.Color.Red;
            //ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + passwordBad + "');", true);
        
        }

        
    }

    private void registerUser()
    {
        
        String connString = System.Configuration.ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ToString();
        conn = new MySql.Data.MySqlClient.MySqlConnection(connString);
        conn.Open();

        //validate repeated email/username

        //queryStr = "";
        //queryStr = ("SELECT * FROM registration.userregistration WHERE userName='" + userName.Text + "' AND email='" + email.Text + "'");


        //cmd.CommandText = "SELECT * FROM registration.userregistration WHERE userName=@userName";
        //cmd.Parameters.AddWithValue("@userName", userName.Text);
        //cmd.Connection = conn;

        //reader = cmd.ExecuteReader();

        //if (reader.HasRows)
        //{
        //    Page.ClientScript.RegisterStartupScript(this.GetType(), "scriptkey", "<script>alert('Username or Email ALREADY TAKEN. Please choose another one!');</script");
        //    userName.Text = "";
        //    email.Text = "";
        //}
        //else
        //{
        //    Page.ClientScript.RegisterStartupScript(this.GetType(), "scriptkey", "<script>alert('Can!');</script");

        //}



        //while (reader.HasRows && reader.Read())
        //{
        //    Fullname = reader.GetString(reader.GetOrdinal("userName")) + " " +
        //        reader.GetString(reader.GetOrdinal("email"));

        //}


        //if (reader.HasRows)
        //{
        //    Session["test"] = Fullname;
        //    Response.BufferOutput = true;
        //    Response.Redirect("Login.aspx", false);
        //}
        //else
        //{

        //    string loginStatus = "Username or email have been taken!";
        //    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + loginStatus + "');", true);
        //    userName.Text = string.Empty;
        //    email.Text = string.Empty;
        //}

        //reader.Close();
        //conn.Close();

        //if (Page.IsValid)
        //{
        //    try
        //    {



        //adding to database

        queryStr = "";

                queryStr = "INSERT INTO registration.userregistration (userName, email, firstName, lastName, password, confirmPassword, phoneNumber, birthdate)" +
                    "VALUES('" + userName.Text + "','" + email.Text + "','" + firstName.Text + "','" + lastName.Text + "','" + password.Text + "','" + confirmPassword.Text + "','" + phoneNumber.Text + "','" + birthdate.Text + "')";
                cmd = new MySql.Data.MySqlClient.MySqlCommand(queryStr, conn);

                cmd.ExecuteReader();
                conn.Close();


                //sendMsg(Email, Username, Firstname, Lastname, Password, random);
                //Session["newEmail"] = Username;
                //Response.Redirect("Activation.aspx");
            


        //    }
        //    catch (Exception msg1)
        //{
        //    Response.Write(msg1);
        //}}

        
        //Generate random number for activation
    }

    public String genCode()
    {
        var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        var stringChars = new char[8];
        var random = new Random();

        for (int i = 0; i < stringChars.Length; i++)
        {
            stringChars[i] = chars[random.Next(chars.Length)];
        }

        var finalString = new String(stringChars);
        return finalString;
    }


    public static void sendMsg(string Email, string Firstname, string Lastname, string Username, string Password, string random)
    {
        
        
        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.gmail.com";
        smtp.Port = 3306;
        smtp.Credentials = new System.Net.NetworkCredential("realitymusic@gmail.com", "RealityMusic");
        smtp.EnableSsl = true;

        MailMessage msg = new MailMessage();
        msg.Subject = "Hello " + Firstname + Lastname;
        msg.Body = "Hello " + Firstname + Lastname + "Thanks for Registering in RealityMusic! Your Account Details are given below:";
        msg.Body += "<tr>";
        msg.Body += "<td>User Name :" + Username + "</td>";
        msg.Body += "</tr>";
        msg.Body += "<tr>";
        msg.Body += "<td>Password :" + Password + "</td>";
        msg.Body += "</tr>";
        msg.Body += "<tr>";
        msg.Body += "<td>Activation Number :" + random + "</td>";
        msg.Body += "</tr>";

        msg.Body += "<tr>";
        msg.Body += "<td>Share with us your music today!</td><td>Team RealityMusic.</td>";
        msg.Body += "</tr>";

        string toAddress = Email; // Add Recepient address
        msg.To.Add(toAddress);

        string fromAddress = "\"RealityMusic \" <realitymusic@gmail.com>"; //create email 
        msg.From = new MailAddress(fromAddress);
        msg.IsBodyHtml = true;

        try
        {
            smtp.Send(msg);

        }
        catch
        {
            throw;
        }


    }

    protected void checkEmailAvail_Click(object sender, EventArgs e)
    {

        String connString = System.Configuration.ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ToString();
        conn = new MySql.Data.MySqlClient.MySqlConnection(connString);
        conn.Open();
        queryStr = "";
        queryStr = "SELECT * FROM registration.userregistration WHERE email='" + email.Text+ "'";

        cmd = new MySql.Data.MySqlClient.MySqlCommand(queryStr, conn);

        reader = cmd.ExecuteReader();

        if (reader.HasRows)
        {
            lblValidateEmail.Text = "Email already exist!";
            lblValidateEmail.ForeColor = System.Drawing.Color.Red;
            email.Text = "";
        }
        else
        {
            lblValidateEmail.Text = "Email ok!";
            lblValidateEmail.ForeColor = System.Drawing.Color.Green;
        }
    }

    protected void checkUsernameAvail_Click(object sender, EventArgs e)
    {
        String connString = System.Configuration.ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ToString();
        conn = new MySql.Data.MySqlClient.MySqlConnection(connString);
        conn.Open();
        queryStr = "";
        queryStr = "SELECT * FROM registration.userregistration WHERE userName='" + userName.Text + "'";

        cmd = new MySql.Data.MySqlClient.MySqlCommand(queryStr, conn);

        reader = cmd.ExecuteReader();

        if (reader.HasRows)
        {
            lblValidateUserName.Text = "Username already exist!";
            lblValidateUserName.ForeColor = System.Drawing.Color.Red;
        }
        else
        {
            lblValidateUserName.Text = "Username ok!";
            lblValidateUserName.ForeColor = System.Drawing.Color.Green;
        }
    }

   
}

          
