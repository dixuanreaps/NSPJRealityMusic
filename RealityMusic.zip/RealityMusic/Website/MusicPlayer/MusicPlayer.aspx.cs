﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.IO;
using System.Text;
using System.Windows.Forms;
using NAudio.Wave;
using System.Collections;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Data;

public partial class Website_MusicPlayer : System.Web.UI.Page
{
    public music musicData;
    public string sJSON;
    public string audioId = "";
    public user mainSingerdata;
    public string username;
    int userid;
    string commentAudioID;
    MySqlCommand cmd = new MySqlCommand();
    MySqlDataAdapter sda = new MySqlDataAdapter();
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        //string url = HttpContext.Current.Request.Url.AbsoluteUri;
        //var uri = new Uri(url);
        //commentAudioID = uri.Query.Substring(9);
        if (Session["username"] == null || Session["userid"] == null) {

        }
        else
        {
            username = (String)Session["username"];
            userid = (int)Session["userid"];
        }

        if ((Request.QueryString["audioId"] != null) && (Request.QueryString["audioId"] != ""))
        {
            audioId = Request.QueryString["audioId"];

            musicData = Searchdatabaseformusic(audioId);
            JavaScriptSerializer oSerializer = new JavaScriptSerializer();
            sJSON = oSerializer.Serialize(musicData);
            String encrypted = Server.MapPath("..\\..\\"+musicData.AudioPath);
            String decrypted = Server.MapPath("..\\..\\Data\\Audio\\Decrypted") + "\\" + musicData.Musicid + ".mp3";
            DecryptFile(encrypted, decrypted, "601f1889667efaebb33b8c12572835da3f027f78");
            //String preview = Server.MapPath("..\\..\\Data\\Audio\\Decrypted") + "\\" + musicData.MusicTitle + "preview.mp3";
            //TrimMp3(decrypted, preview);
            Label1.Text = musicData.MusicTitle;
            Label2.Text = musicData.Likes.ToString();
            Label3.Text = musicData.Views.ToString();
            Label4.Text = musicData.PriceType.ToString();
            
            mainSingerdata = Searchdatabaseforuserdata(musicData.Userid.ToString());
            uploadername.InnerText = mainSingerdata.userName;
            description.InnerHtml = musicData.Description;
        }
        show();
    }

    public void like_button(object Source, EventArgs e)
    {
        if ((Request.QueryString["audioId"] != null) && (Request.QueryString["audioId"] != ""))
        {
            string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
            using (MySqlConnection con = new MySqlConnection(cs))
            {
                con.Open();
                String query = "UPDATE music SET Likes = Likes + 1 WHERE Musicid = @search";
                MySqlCommand command = new MySqlCommand(query, con);
                command.Parameters.AddWithValue("@search", audioId);
                command.ExecuteNonQuery();
                Response.Redirect("MusicPlayer.aspx?audioId=" + audioId);
            }
        }
    }

    //retrieve music table data
    public music Searchdatabaseformusic(String searchvalue)
    {
        //List<music> al = new List<music>();
        music currentmusic = null;
        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT music.* FROM music WHERE Musicid = @search";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@search", searchvalue);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (searchvalue == null || searchvalue == "")
                    {
                        break;
                    }
                    else
                    {
                        currentmusic = new music(reader.GetString(reader.GetOrdinal("MusicID")), reader.GetInt32(reader.GetOrdinal("UserID")), reader.GetString(reader.GetOrdinal("MusicTitle")), reader.GetString(reader.GetOrdinal("Description")), reader.GetString(reader.GetOrdinal("AudioPath")), reader.GetString(reader.GetOrdinal("ImagePath")), reader.GetString(reader.GetOrdinal("PriceType")), reader.GetString(reader.GetOrdinal("UploadDate")), reader.GetInt32(reader.GetOrdinal("Views")), reader.GetInt32(reader.GetOrdinal("Likes")), reader.GetInt32(reader.GetOrdinal("NoOfReports")));
                    }
                }

                if (reader != null)
                    reader.Close();
            }

        }
        return currentmusic;
    }

    //retrieve username of the user that upload music
    //changes to be made
    public user Searchdatabaseforuserdata(String searchvalue)
    {
        user singer = null;
        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {
            con.Open();
            String query = "SELECT * FROM user WHERE userid = @search";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@search", searchvalue);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (searchvalue == null || searchvalue == "")
                    {
                        break;
                    }
                    else
                    {
                        singer = new user(reader.GetInt32(0), reader.GetString(1), reader.GetString(2), reader.GetString(4), reader.GetString(5), reader.GetString(6), reader.GetString(7), reader.GetString(8));
                    }
                }

                if (reader != null)
                    reader.Close();
            }
        }
        return singer;
    }

    //Symmetric Decryption of File
    //InputFile(Encrypted) and OutputFile(Decrypted) are paths
    private void DecryptFile(string inputFile, string outputFile, string key)
    {
        try
        {
            byte[] keyBytes = Encoding.Unicode.GetBytes(key);

            Rfc2898DeriveBytes derivedKey = new Rfc2898DeriveBytes(key, keyBytes);

            RijndaelManaged rijndaelCSP = new RijndaelManaged();
            rijndaelCSP.Padding = PaddingMode.ANSIX923;
            rijndaelCSP.Key = derivedKey.GetBytes(rijndaelCSP.KeySize / 8);
            rijndaelCSP.IV = derivedKey.GetBytes(rijndaelCSP.BlockSize / 8);
            ICryptoTransform decryptor = rijndaelCSP.CreateDecryptor();

            FileStream inputFileStream = new FileStream(inputFile, FileMode.Open, FileAccess.Read);

            CryptoStream decryptStream = new CryptoStream(inputFileStream, decryptor, CryptoStreamMode.Read);

            byte[] inputFileData = new byte[(int)inputFileStream.Length];
            int data = decryptStream.Read(inputFileData, 0, (int)inputFileStream.Length);

            //int decrypt_length = decryptStream.Read(inputFileData, 0, (int)inputFileStream.Length);
            FileStream outputFileStream = new FileStream(outputFile, FileMode.Create, FileAccess.Write);
            outputFileStream.Write(inputFileData, 0, data);
            outputFileStream.Flush();

            rijndaelCSP.Clear();

            decryptStream.Close();
            inputFileStream.Close();
            outputFileStream.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Decryption Failed!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        //MessageBox.Show("File Decryption Complete!");
    }

    void TrimMp3(string inputPath, string outputPath)
    {

        using (var reader = new Mp3FileReader(inputPath))
        using (var writer = File.Create(outputPath))
        {
            Mp3Frame frame;
            var count = 0;
            var startPostion = TimeSpan.FromSeconds(0);
            var endPostion = TimeSpan.FromSeconds(45);
            while ((frame = reader.ReadNextFrame()) != null)
            {
                if (count > 1750) //retrieve a sample of 500 frames
                    return;
                if (reader.CurrentTime >= startPostion)
                {
                    if (reader.CurrentTime < endPostion)
                    {
                        count++;
                        writer.Write(frame.RawData, 0, frame.RawData.Length);
                    }
                    else break;
                }
            }
        }
    }

    //submiting comment
    protected void Submit_Btn_Click(object sender, EventArgs e)
    {

        if (username != null || userid != null) //logged in
        {
                System.Web.UI.WebControls.TextBox tb;
                System.Web.UI.WebControls.Label sql;
                tb = (System.Web.UI.WebControls.TextBox)loginview1.FindControl("TxtDesc");
                sql = (System.Web.UI.WebControls.Label)loginview1.FindControl("sql");

                //putting data into database
                //MySqlConnection connection = new MySqlConnection("server=localhost;user id=amiir;database=test; allowuservariables=True; password=password");
                string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
                MySqlConnection connection = new MySqlConnection(cs);
                connection.Open();
                string insertQuery = "INSERT INTO comments (commentDescription,userID,username,audioID,commentTimestamp) VALUES (@commentDescription,@userID,@username,@audioID,@commentTimestamp)";

                using (MySqlCommand command = new MySqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@commentDescription", tb.Text);
                    command.Parameters.AddWithValue("@userID", userid);
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@audioID", audioId);
                    command.Parameters.AddWithValue("@commentTimestamp", DateTime.Now);

                    int result = command.ExecuteNonQuery();
                    Response.Redirect(Request.Url.AbsoluteUri);

                    if (result < 0)
                        sql.Visible = true;
                    sql.Text = ("Error inserting data into Database!");
                }
                connection.Close();
            }
        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Please log in before commenting!" + "');window.location='../Registration/Login.aspx';", true);
        }
    }

    protected void show()
    {
        //MySqlConnection connection = new MySqlConnection("server=localhost;user id=amiir;database=test; allowuservariables=True; password=password");
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        MySqlConnection connection = new MySqlConnection(cs);
        connection.Open();

        cmd.CommandText = "SELECT * FROM comments WHERE audioID =@audioid";
        cmd.Parameters.AddWithValue("@audioid", audioId);
        cmd.Connection = connection;
        sda.SelectCommand = cmd;
        sda.Fill(ds, "comments");
        Repeater1.DataSource = ds;
        Repeater1.DataBind();
    }

}


