﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.IO;
using System.Text;
using System.Windows.Forms;
using NAudio.Wave;
using System.Collections;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Data;
using System.Web.UI.HtmlControls;

public partial class Website_MusicPlayer : System.Web.UI.Page
{
    public music musicData;
    public string sJSON;
    public string audioId = "";
    public user mainSingerdata;
    public string username;
    int userid;
    string commentAudioID;
    MySqlCommand cmd = new MySqlCommand();
    MySqlDataAdapter sda = new MySqlDataAdapter();
    DataSet ds = new DataSet();

    public List<Playlist> playlist;
    public string playlistString;
    bool checkLikeOrNo, error;
    public string audioExtension;
    string descDB;
   
    protected void Page_Load(object sender, EventArgs e)
    {
        string url = HttpContext.Current.Request.Url.AbsoluteUri;
        var uri = new Uri(url);
        commentAudioID = uri.Query.Substring(9);
        like_add.Visible = false;
        if ((Request.QueryString["audioId"] != null) && (Request.QueryString["audioId"] != ""))
        {
            audioId = Request.QueryString["audioId"];
            JavaScriptSerializer oSerializer = new JavaScriptSerializer();
            if (Session["username"] == null || Session["userid"] == null)
            {

            }
            else
            {
                username = (String)Session["username"];
                userid = (int)Session["userid"];

                checkLikeOrNo = checkLorDL();

                if (checkLikeOrNo)
                {
                    icon.Attributes.Add("Class", "glyphicon glyphicon-thumbs-up");
                }
                else
                {
                    icon.Attributes.Add("Class", "glyphicon glyphicon-thumbs-up unlike");
                }


                playlist = SearchPlaylistdatabase();
                playlistString = oSerializer.Serialize(playlist);
                button_test();
            }
            if (playlistString == null || playlistString == "")
            {
                playlistString = "\"Empty\"";
            }

            if ((String)Session[audioId] == null || (String)Session[audioId] == "")
            {
                viewsUpdate();
                Session[audioId] = "Views Updated";
            }
            else
            {
            }



            musicData = Searchdatabaseformusic(audioId);
            sJSON = oSerializer.Serialize(musicData);

            Label1.Text = musicData.MusicTitle;
            Label2.Text = musicData.Likes.ToString();
            Label3.Text = musicData.Views.ToString();
            Label4.Text = musicData.PriceType.ToString();

            //mainsingerdata use for decryption;
            mainSingerdata = Searchdatabaseforuserdata(musicData.Userid.ToString());
            uploadername.InnerText = musicData.Username;
            description.InnerHtml = musicData.Description;

            String encrypted = Server.MapPath("..\\..\\" + musicData.AudioPath);
            audioExtension = Path.GetExtension(encrypted);
            String decrypted = Server.MapPath("..\\..\\Data\\Audio\\Decrypted") + "\\" + musicData.Musicid + audioExtension;
            DecryptFile(encrypted, decrypted, Hash(mainSingerdata.birthdate));
            audioExtension = "\"" + audioExtension + "\"";
            //String preview = Server.MapPath("..\\..\\Data\\Audio\\Decrypted") + "\\" + musicData.Musicid + "preview.mp3";
            //TrimMp3(decrypted, preview);

        }
        CommentsBind();
        //UpdatePanel2.Update();
    }

    //Like buttons
    public void like_button(object Source, EventArgs e)
    {
        try
        {
            if (Session["username"] == null || Session["userid"] == null)
            {
                like_add.Visible = true;
                like_add.Text = "Please sign in first before u can like the music";
                like_add.ForeColor = System.Drawing.Color.Red;
            }
            else
            {

                if ((Request.QueryString["audioId"] != null) && (Request.QueryString["audioId"] != ""))
                {
                    //like
                    if (checkLikeOrNo)
                    {
                        likefunction();
                        icon.Attributes.Add("Class", "glyphicon glyphicon-thumbs-up unlike");
                    }
                    //dislike
                    else
                    {
                        dislikefunction();
                        icon.Attributes.Add("Class", "glyphicon glyphicon-thumbs-up");
                    }
                }
            }
        }
        catch (IOException ex)
        {
            Response.Write(ex);
        }
    }

    //retrieve music table data
    public music Searchdatabaseformusic(String searchvalue)
    {
        //List<music> al = new List<music>();
        music currentmusic = null;
        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT music.* FROM music WHERE audioID = @search";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@search", searchvalue);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (searchvalue == null || searchvalue == "")
                    {
                        break;
                    }
                    else
                    {
                        currentmusic = new music(reader.GetString(reader.GetOrdinal("audioID")), reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("username")), reader.GetString(reader.GetOrdinal("musicTitle")), reader.GetString(reader.GetOrdinal("description")), reader.GetString(reader.GetOrdinal("audioPath")), reader.GetString(reader.GetOrdinal("imagePath")), reader.GetString(reader.GetOrdinal("priceType")), reader.GetString(reader.GetOrdinal("uploadDate")), reader.GetInt32(reader.GetOrdinal("views")), reader.GetInt32(reader.GetOrdinal("likes")), reader.GetInt32(reader.GetOrdinal("noOfReports")));
                    }
                }

                if (reader != null)
                    reader.Close();
            }

        }
        return currentmusic;
    }

    //retrieve username of the user that upload music
    //changes to be made
    public user Searchdatabaseforuserdata(String searchvalue)
    {
        user singer = null;
        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {
            con.Open();
            String query = "SELECT * FROM useraccount WHERE userID = @search";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@search", searchvalue);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (searchvalue == null || searchvalue == "")
                    {
                        break;
                    }
                    else
                    {
                        singer = new user(reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("email")), reader.GetString(reader.GetOrdinal("username")), reader.GetString(reader.GetOrdinal("phoneNumber")), reader.GetString(reader.GetOrdinal("firstName")), reader.GetString(reader.GetOrdinal("lastName")), reader.GetString(reader.GetOrdinal("country")), reader.GetString(reader.GetOrdinal("imagePath")), reader.GetString(reader.GetOrdinal("birthdate")));
                    }
                }

                if (reader != null)
                    reader.Close();
            }
        }
        return singer;
    }

    //Symmetric Decryption of File
    //InputFile(Encrypted) and OutputFile(Decrypted) are paths
    private void DecryptFile(string inputFile, string outputFile, string key)
    {
        try
        {
            byte[] keyBytes = Encoding.Unicode.GetBytes(key);

            Rfc2898DeriveBytes derivedKey = new Rfc2898DeriveBytes(key, keyBytes);

            RijndaelManaged rijndaelCSP = new RijndaelManaged();
            rijndaelCSP.Padding = PaddingMode.ANSIX923;
            rijndaelCSP.Key = derivedKey.GetBytes(rijndaelCSP.KeySize / 8);
            rijndaelCSP.IV = derivedKey.GetBytes(rijndaelCSP.BlockSize / 8);
            ICryptoTransform decryptor = rijndaelCSP.CreateDecryptor();

            FileStream inputFileStream = new FileStream(inputFile, FileMode.Open, FileAccess.Read);

            CryptoStream decryptStream = new CryptoStream(inputFileStream, decryptor, CryptoStreamMode.Read);

            byte[] inputFileData = new byte[(int)inputFileStream.Length];
            int data = decryptStream.Read(inputFileData, 0, (int)inputFileStream.Length);

            //int decrypt_length = decryptStream.Read(inputFileData, 0, (int)inputFileStream.Length);
            FileStream outputFileStream = new FileStream(outputFile, FileMode.Create, FileAccess.Write);
            outputFileStream.Write(inputFileData, 0, data);
            outputFileStream.Flush();

            rijndaelCSP.Clear();

            decryptStream.Close();
            inputFileStream.Close();
            outputFileStream.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Decryption Failed!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
    }

    //preview
    void TrimMp3(string inputPath, string outputPath)
    {
        using (var reader = new Mp3FileReader(inputPath))
        using (var writer = File.Create(outputPath))
        {
            Mp3Frame frame;
            var count = 0;
            var startPostion = TimeSpan.FromSeconds(0);
            var endPostion = TimeSpan.FromSeconds(45);
            while ((frame = reader.ReadNextFrame()) != null)
            {
                if (count > 1750) //retrieve a sample of 500 frames
                    return;
                if (reader.CurrentTime >= startPostion)
                {
                    if (reader.CurrentTime < endPostion)
                    {
                        count++;
                        writer.Write(frame.RawData, 0, frame.RawData.Length);
                    }
                    else break;
                }
            }
        }
    }

    //list of Playlist audio data
    public List<Playlist> SearchPlaylistdatabase()
    {
        List<Playlist> al = new List<Playlist>();

        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT * FROM playlist WHERE userID = @userid AND playlistName not like \'Favourite\'";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@userid", userid);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    al.Add(new Playlist(reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("playlistName")), reader.GetInt32(reader.GetOrdinal("playlistID"))));
                }

                if (reader != null)
                    reader.Close();
            }

        }
        return al;
    }

    //Favourite Playlist 
    public Playlist SearchFavouritePlaylistdatabase()
    {
        Playlist al = null;

        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT * FROM playlist WHERE userID = @userid AND playlistName = \'Favourite\'";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@userid", userid);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    al = new Playlist(reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("playlistName")), reader.GetInt32(reader.GetOrdinal("playlistID")));
                }

                if (reader != null)
                    reader.Close();
            }

        }
        return al;
    }

   //display in add to playlist
    protected void button_test()
    {
        if (playlist.Count.Equals(0))
        {
            HtmlGenericControl li = new HtmlGenericControl("li");
            li.Attributes.Add("class", "play-list");

            System.Web.UI.WebControls.Label x = new System.Web.UI.WebControls.Label();
            x.Text = "No playlist is created in this Account. Please create one";
            x.Attributes.Add("class", "container");
            playlistListing.Controls.Add(li);
            li.Controls.Add(x);
        }
        else
        {
            for (int i = 0; i < playlist.Count(); i++)
            {
                HtmlGenericControl li = new HtmlGenericControl("li");
                li.Attributes.Add("class", "play-list");

                System.Web.UI.WebControls.Button x = new System.Web.UI.WebControls.Button();
                x.ID = playlist[i].playlistName;
                x.Text = playlist[i].playlistName;
                x.Command += new CommandEventHandler(addtoPlaylist_click);
                x.Attributes.Add("class", "btn btn-default playlistbutton");
                playlistListing.Controls.Add(li);
                li.Controls.Add(x);
            }
        }
    }

    //playlist
    protected void addtoPlaylist_click(object sender, EventArgs e)
    {

        //checking whic button is clicked
        System.Web.UI.WebControls.Button clickedButton = sender as System.Web.UI.WebControls.Button;
        bool correct = false;
        string playlistNametoadd = null;
        int playlistid = 0;
        for (int i = 0; i < playlist.Count(); i++)
        {
            if (clickedButton.Text == playlist[i].playlistName)
            {
                playlistid = playlist[i].playlistID;
                playlistNametoadd = playlist[i].playlistName;

                correct = true;
            }
        }

        if (!correct)
        {
            return;
        }
        else
        {
            //gather data in the particular playlist
            String query;
            MySqlCommand command;
            List<playlistItems> al = new List<playlistItems>();
            string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
            using (MySqlConnection con = new MySqlConnection(cs))
            {
                con.Open();
                query = "SELECT p.userID, pl.audioID, p.playlistName, p.playlistID, pl.musicTitle FROM playlist p INNER JOIN playlistitems pl ON p.playlistID = pl.playlistID WHERE p.playlistID = @value AND userID = @userid";
                command = new MySqlCommand(query, con);
                command.Parameters.AddWithValue("@value", playlistid);
                command.Parameters.AddWithValue("@userid", userid);
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        al.Add(new playlistItems(reader.GetString(reader.GetOrdinal("audioID")), reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("playlistName")), reader.GetString(reader.GetOrdinal("playlistID")), reader.GetString(reader.GetOrdinal("musicTitle"))));
                    }

                    if (reader != null)
                        reader.Close();
                    con.Close();
                }
            }

            int count = 0;
            bool duplicate = false;
            //deny adding to playlist if music is already in playlist
            while (count < al.Count())
            {
                if (al[count].audioID == audioId)
                {
                    duplicate = true;
                    like_add.Visible = true;
                    like_add.Text = "Music already in playlist";
                    like_add.ForeColor = System.Drawing.Color.Red;
                    break;
                }
                count++;
            }

            //add to playlist
            if (!duplicate)
            {
                using (MySqlConnection con = new MySqlConnection(cs))
                {
                    con.Open();
                    query = "INSERT INTO playlistItems (playlistID,audioID,musicTitle,playlistName) VALUES (@playlistID,@audioID,@musicTitle,@playlistName)";
                    command = new MySqlCommand(query, con);
                    command.Parameters.AddWithValue("@playlistID", playlistid);
                    command.Parameters.AddWithValue("@audioID", audioId);
                    command.Parameters.AddWithValue("@musicTitle", musicData.MusicTitle);
                    command.Parameters.AddWithValue("@playlistName", playlistNametoadd);
                    command.ExecuteNonQuery();
                    con.Close();
                }
                like_add.Visible = true;
                like_add.Text = "Music added to playlist";
                like_add.ForeColor = System.Drawing.Color.ForestGreen;
            }
        }
    }

    //like function
    protected void likefunction()
    {
        Playlist Fplay = SearchFavouritePlaylistdatabase();

        if (Fplay == null)
        {
            createFavourite();
            addFplaylistItems();
        }
        else
        {
            addFplaylistItems();
        }

        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {
            con.Open();
            String query = "UPDATE music SET likes = likes + 1 WHERE audioID = @search";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@search", audioId);
            command.ExecuteNonQuery();
            //Response.Redirect("MusicPlayer.aspx?audioId=" + audioId);
            Label2.Text = (musicData.Likes + 1).ToString();
            like_add.Visible = true;
            like_add.Text = "Music liked and added to 'Favourite' playlist";
            like_add.ForeColor = System.Drawing.Color.ForestGreen;
            Session[audioId + "likes"] = "liked";
            con.Close();
        }
    }

    protected void dislikefunction()
    {

        deletefplaylistItems();

        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {
            con.Open();
            String query = "UPDATE music SET likes = likes - 1 WHERE audioID = @search";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@search", audioId);
            command.ExecuteNonQuery();
            Label2.Text = (musicData.Likes - 1).ToString();
            like_add.Visible = true;
            like_add.Text = "Music unliked and removed from 'Favourite' Playlist";
            like_add.ForeColor = System.Drawing.Color.ForestGreen;
            Session[audioId + "likes"] = null;
            con.Close();
        }
    }

    //create favourite playlist if Favourite playlist is not found
    protected void createFavourite()
    {
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {
            con.Open();
            String query = "INSERT INTO playlist (userID,playlistName) VALUES (@userID,\'Favourite\')";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@userID", userid);
            command.ExecuteNonQuery();
        }
    }

    //add favourite playlist
    protected void addFplaylistItems()
    {
        Playlist al = SearchFavouritePlaylistdatabase();

        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {
            con.Open();
            String query = "INSERT INTO playlistItems (playlistID,audioID,musicTitle,playlistName) VALUES (@playlistID,@audioID,@musicTitle,@playlistName)";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@playlistID", al.playlistID);
            command.Parameters.AddWithValue("@audioID", audioId);
            command.Parameters.AddWithValue("@musicTitle", musicData.MusicTitle);
            command.Parameters.AddWithValue("@playlistName", "Favourite");
            command.ExecuteNonQuery();
        }
    }

    //delete favourite
    protected void deletefplaylistItems()
    {
        Playlist al = SearchFavouritePlaylistdatabase();
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {
            con.Open();
            String query = "DELETE FROM playlistItems WHERE playlistID = @playlistID AND audioID = @audioID AND playlistName = @playlistName";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@playlistID", al.playlistID);
            command.Parameters.AddWithValue("@audioID", audioId);
            command.Parameters.AddWithValue("@playlistName", "Favourite");
            command.ExecuteNonQuery();
        }
    }

    //check if userlogin already and their favourite playlist contains the particular music
    protected bool checkLorDL()
    {
        Playlist al = SearchFavouritePlaylistdatabase();
        if (al == null)
        {
            createFavourite();
            al = SearchFavouritePlaylistdatabase();
        }
        playlistItems itemvalue = null;
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT p.userID, pl.audioID, p.playlistName, p.playlistID, pl.musicTitle FROM playlist p INNER JOIN playlistitems pl ON p.playlistID = pl.playlistID WHERE p.playlistID = @playlistID AND userID = @userid AND pl.audioID = @audioID";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@playlistID", al.playlistID); // commented 
            command.Parameters.AddWithValue("@userid", userid);
            command.Parameters.AddWithValue("@audioID", audioId);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {

                    itemvalue = new playlistItems(reader.GetString(reader.GetOrdinal("audioID")), reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("playlistName")), reader.GetString(reader.GetOrdinal("playlistID")), reader.GetString(reader.GetOrdinal("musicTitle")));
                }

                if (reader != null)
                    reader.Close();
            }

        }

        if (itemvalue != null)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    protected void viewsUpdate()
    {
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {
            con.Open();
            String query = "UPDATE music SET views = views + 1 WHERE audioID = @search";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@search", audioId);
            command.ExecuteNonQuery();
        }
    }

    static string Hash(string input)
    {
        using (SHA256Managed sha256 = new SHA256Managed())
        {
            var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
            var sb = new StringBuilder(hash.Length * 2);

            foreach (byte b in hash)
            {
                // can be "x2" if you want lowercase
                sb.Append(b.ToString("X2"));
            }

            return sb.ToString();
        }
    }

    protected void report_btn(object sender, EventArgs e)
    {
        Response.Redirect("/Website/MusicPlayer/ReportingPage.aspx?musicid=" +audioId);
    }

    
    //binding comments
    private void CommentsBind()
    {
        cmd.Parameters.Clear();
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        MySqlConnection con = new MySqlConnection(cs);
        con.Open();
        cmd.CommandText = "SELECT * FROM comments where audioID=@audioId";
        cmd.Parameters.AddWithValue("@audioId", audioId);
        cmd.Connection = con;
        sda.SelectCommand = cmd;
        sda.Fill(ds, "comments");
        GridViewComment.DataSource = ds;
        GridViewComment.DataBind();
        con.Close();
    }

    



    //inserting comments
    protected void Submit_Btn_Click(object sender, EventArgs e)
    {
       
        System.Web.UI.WebControls.Label Error;
        Error = (System.Web.UI.WebControls.Label)loginview1.FindControl("Error");
        System.Web.UI.WebControls.TextBox tb;
        tb = (System.Web.UI.WebControls.TextBox)loginview1.FindControl("TxtDesc");
      
        if (tb.Text == null || tb.Text == "")
        {
            error = true;
            Error.Visible = true;
            Error.Text = "Comment cannot be empty!";
        }

        //checking for duplicate data (comments)
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString; //database connection string (linked to web config)
        MySqlDataReader reader;

        using (MySqlConnection con = new MySqlConnection(cs))
        {
            con.Open();
            string selectQuery = "SELECT commentDescription FROM comments where userID=@userID";
            MySqlCommand cmd = new MySqlCommand(selectQuery, con);
            cmd.Parameters.AddWithValue("@userID", userid);
            reader = cmd.ExecuteReader();
            while (reader.HasRows && reader.Read())
            {
                descDB = reader.GetString(reader.GetOrdinal("commentDescription"));
            }
            if (descDB != null)

            {
                if (descDB.Equals(tb.Text))
                {
                    error = true;
                    Error.Visible = true;
                    Error.Text = "Duplicate data!";
                }
            }
            con.Close();
        }  //check for duplicate end (comments)

       
        //StringBuilder sb = new StringBuilder(HttpUtility.HtmlEncode(tb.Text));
        //// Selectively allow  <b> and <i>
        //sb.Replace("&lt;b&gt;", "<b>");
        //sb.Replace("&lt;/b&gt;", "");
        //sb.Replace("&lt;i&gt;", "<i>");
        //sb.Replace("&lt;/i&gt;", "");

        //prevent css
        if (tb.Text.Contains("<b>") || tb.Text.Contains("</b>") || tb.Text.Contains("<i>") || tb.Text.Contains("</i>"))
        {
            tb.Text = Server.HtmlDecode(tb.Text);
        }
        else
        {
            tb.Text = Server.HtmlEncode(tb.Text);
        }
        //prevent css end

        if (error == false)
        {
            if (username != null)
            {
                //putting comments data into database

                using (MySqlConnection con = new MySqlConnection(cs))
                {
                    con.Open();

                    string insertQuery = "INSERT INTO comments (commentDescription,userID,username,audioID,commentTimestamp) VALUES (@commentDescription,@userID,@username,@audioID,@commentTimestamp)";
                    MySqlCommand command = new MySqlCommand(insertQuery, con);
                    command.Parameters.AddWithValue("@commentDescription", tb.Text);
                    command.Parameters.AddWithValue("@userID", userid);
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@audioID", audioId);
                    command.Parameters.AddWithValue("@commentTimestamp", DateTime.Now);

                    int result = command.ExecuteNonQuery();
                    con.Close();
                    CommentsBind();
                    //UpdatePanel2.Update();

                }

            }

        }
        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Please log in before commenting!" + "');", true);
        }
    }

}
