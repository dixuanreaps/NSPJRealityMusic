﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Configuration;

public partial class ReportingPage : System.Web.UI.Page
{
    string audioID,reportDescDB;
    int userid;
    bool error;
    string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {

        //getting userid of current session
        userid = (int)Session["userid"];

        //getting audioID 
        string url = HttpContext.Current.Request.Url.AbsoluteUri;
        var uri = new Uri(url);
        audioID = uri.Query.Substring(9);
    }

   
    protected void SubmitBtn_Click(object sender, EventArgs e)
    {
        if (ReportTxt.Text == null)
        {
            error = true;
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Report is empty!" + "');", true);
        }

        //check for duplicate data
        MySqlDataReader reader;

        using (MySqlConnection con = new MySqlConnection(cs))
        {
            con.Open();
            string selectQuery = "SELECT ReportDesc FROM reports where userID=@userID";
            MySqlCommand cmd = new MySqlCommand(selectQuery, con);
            cmd.Parameters.AddWithValue("@userID", userid);
            reader = cmd.ExecuteReader();
            while (reader.HasRows && reader.Read())
            {
                reportDescDB = reader.GetString(reader.GetOrdinal("ReportDesc"));
            }
            if (reportDescDB != null)

            {
                if (reportDescDB.Equals(ReportTxt.Text))
                {
                    error = true;
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Error in submission due to duplicate Data!" + "');", true);
                }
            }
            con.Close();
        } //check for duplicate end

        if (error == false)  //putting values in reports table
        {
            using (MySqlConnection con = new MySqlConnection(cs))
            {
                con.Open();
                string insertQuery = "INSERT INTO reports (UserID,MusicID,ReportDesc,ReportTime) VALUES (@UserID,@MusicID,@ReportDesc,@ReportTime); UPDATE music SET noOfReports=noOfReports+1 WHERE audioID=@MusicID";

                MySqlCommand command = new MySqlCommand(insertQuery, con);

                command.Parameters.AddWithValue("@UserID", userid);
                command.Parameters.AddWithValue("@MusicID", audioID);
                command.Parameters.AddWithValue("@ReportDesc", ReportTxt.Text);
                command.Parameters.AddWithValue("@ReportTime", DateTime.Now);

                int result = command.ExecuteNonQuery();

                con.Close();
            }
            Response.Redirect("AfterReport.aspx");
        }
    }
    protected void CancelBtn_Click(object sender, EventArgs e)
    {

    }

}