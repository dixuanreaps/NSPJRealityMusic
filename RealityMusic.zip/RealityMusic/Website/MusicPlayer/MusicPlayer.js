﻿document.addEventListener("DOMContentLoaded", function(event) {

var music = document.getElementById('music'); // id for audio element
var duration= music.duration; // Duration of audio clip, calculated here for embedding purposes
var pButton = document.getElementById('pButton'); // play button
var playhead = document.getElementById('playhead'); // playhead
var timeline = document.getElementById('timeline'); // timeline
var volume = document.getElementById('volume'); // volume button
var volumecircle = document.getElementById('volumehead'); // volumecircle
var volumeline = document.getElementById('volumeline');//volumeLine
var Soundvolume = music.volume;//volume of music

//currentTime of song
var current = document.getElementById('current');
    music.addEventListener('timeupdate', function () {
        var minutes;
        var seconds;
        var secondsvalues;
        minutes = music.currentTime / 60;
        seconds = music.currentTime % 60;

        var secondsvalue = parseInt(seconds);
        if (secondsvalue < 10) {
            secondsvalue = "0" + secondsvalue;
        }

       current.innerHTML = parseInt(minutes) +":"+ secondsvalue;
});

    //total duration of song
    music.addEventListener('loadedmetadata', function () {
        var minutesforduration = music.duration / 60;
        var secondsforduration = music.duration % 60;
        minutesforduration = parseInt(minutesforduration);
        secondsforduration = parseInt(secondsforduration);

        if (secondsforduration < 10) {
            secondsforduration = "0" + secondsforduration;
        }
        document.getElementById("duration").innerHTML = minutesforduration + ":" + secondsforduration;
        document.getElementById("Dura").innerHTML = minutesforduration + ":" + secondsforduration;
    });
    


// timeline width adjusted for playhead
var timelineWidth = timeline.offsetWidth - playhead.offsetWidth;

    // volume width adjusted for volhead
var volLineWidth = volumeline.offsetWidth - volumecircle.offsetWidth;

// play button event listenter
pButton.addEventListener("click", play);

// volume button event listenter
volume.addEventListener("click", mute);

// timeupdate event listener
music.addEventListener("timeupdate", timeUpdate, false);

// makes timeline clickable
timeline.addEventListener("click", function(event) {
    moveplayhead(event);
    music.currentTime = duration * clickPercent(event);
}, false);

// makes volumeline clickable
volumeline.addEventListener("click", function (event) {
    movevolumehead(event);
    var value = Soundvolume * volclickPercent(event);
    if (value > 1) {
        music.volume = 1;
    }
    else if (value < 0) {
        music.volume = 0
    }
    else {
        music.volume = Soundvolume * volclickPercent(event);
    }
}, false);

// returns click as decimal (.77) of the total timelineWidth
function clickPercent(event) {
    return (event.clientX - getPosition(timeline)) / timelineWidth;
}

function volclickPercent(event) {
        return (event.clientX - getPosition(volumeline)) / volLineWidth;
}

// makes playhead draggable
playhead.addEventListener('mousedown', mouseDown, false);
window.addEventListener('mouseup', mouseUp, false);


//make volumehead draggable
//volumecircle.addEventListener('mousedown', volmouseDown, false); //cause some error in code
//window.addEventListener('mouseup', volmouseUp, false);

// Boolean value so that audio position is updated only when the playhead is released
var onplayhead = false;

// mouseDown EventListener
function mouseDown() {
    onplayhead = true;
    window.addEventListener('mousemove', moveplayhead, true);
    music.removeEventListener('timeupdate', timeUpdate, false);
}

// mouseDown EventListener
function volmouseDown() {
    onplayhead = true;
    window.addEventListener('mousemove', movevolumehead, true);
    music.removeEventListener('volumeupdate', volumeupdate, false);
}

// mouseUp EventListener
// getting input from all mouse clicks
function mouseUp(event) {
    if (onplayhead == true) {
        moveplayhead(event);
        window.removeEventListener('mousemove', moveplayhead, true);
        // change current time
        music.currentTime = duration * clickPercent(event);
        music.addEventListener('timeupdate', timeUpdate, false);
    }
    onplayhead = false;
}
// mousemove EventListener

// volmouseUp EventListener
// getting input from all mouse clicks
function volmouseUp(event) {
    if (onplayhead == true) {
        var value = Soundvolume * volclickPercent(event);
        movevolumehead(event);
        window.removeEventListener('mousemove', movevolumehead, true);
        if (value > 1) {
            music.volume = 1;
        }
        else if (value < 0) {
            music.volume = 0
        }
        else {
            music.volume = Soundvolume * volclickPercent(event);
        }
        music.addEventListener('volumechange', volumeupdate, false);
    }
    onplayhead = false;
}
// volmousemove EventListener
// Moves playhead as user drags
function moveplayhead(event) {
    var newMargLeft = event.clientX - getPosition(timeline);

    if (newMargLeft >= 0 && newMargLeft <= timelineWidth) {
        playhead.style.marginLeft = newMargLeft + "px";
    }
    if (newMargLeft < 0) {
        playhead.style.marginLeft = "0px";
    }
    if (newMargLeft > timelineWidth) {
        playhead.style.marginLeft = timelineWidth + "px";
    }
}

// Moves volhead as user drags
function movevolumehead(event) {
    var newMargLeft = event.clientX - getPosition(volumeline);

    if (newMargLeft >= 0 && newMargLeft <= volLineWidth) {
        volumecircle.style.marginLeft = newMargLeft + "px";
    }
    if (newMargLeft < 0) {
        volumecircle.style.marginLeft = "0px";
    }
    if (newMargLeft > volLineWidth) {
        volumecircle.style.marginLeft = volLineWidth + "px";
    }
}

// timeUpdate
// Synchronizes playhead position with current point in audio
function timeUpdate() {
    var playPercent = timelineWidth * (music.currentTime / duration);
    playhead.style.marginLeft = playPercent + "px";
    if (music.currentTime == duration) {
        pButton.className = "";
        pButton.className = "play";
    }
}

// volumeUpdate
// Synchronizes playhead position with current point in audio
    function volumeupdate() {
        var playPercent = volLineWidth * (music.volume);

        volumecircle.style.marginLeft = playPercent + "px";
        if (music.volume > 0.75) {
            volume.class = "";
            volume.className = "volume75";
            if (music.muted == true) {
                volume.class = "";
                volume.className = "volume0";
            }
        }
        else if (music.volume > 0.5 && music.volume < 0.75) {
            volume.class = "";
            volume.className = "volume50";
            if (music.muted == true) {
                volume.class = "";
                volume.className = "volume0";
            }
        }
        else if (music.volume > 0.25 && music.volume < 0.50) {
            volume.class = "";
            volume.className = "volume25";
            if (music.muted == true) {
                volume.class = "";
                volume.className = "volume0";
            }
        }
        else if (music.volume == 0) {
            volume.class = "";
            volume.className = "volume0";
        }
}

//Play and Pause
function play() {
    // start music
    if (music.paused) {
        music.play();
        // remove play, add pause
        pButton.className = "";
        pButton.className = "pause";
    } else { // pause music
        music.pause();
        // remove pause, add play
        pButton.className = "";
        pButton.className = "play";
    }
}

//Play and Pause
function mute() {
    // volume
    if (music.muted == true || music.volume == 0) {
        // change icon
        music.muted = false;
        if (music.volume > 0.75) {
            volume.class = "";
            volume.className = "volume75";
        }
        else if (music.volume > 0.5 && music.volume < 0.75) {
            volume.class = "";
            volume.className = "volume50";
        }
        else if (music.volume > 0.25 && music.volume < 0.5) {
            volume.class = "";
            volume.className = "volume25";
        }
    }
    else if (music.muted == false) { // mute volume
        //change icon
        music.muted = true;
        volume.className = "";
        volume.className = "volume0";
    }
}

// Gets audio file duration
music.addEventListener("canplaythrough", function() {
    duration = music.duration;
}, false);

// getPosition
// Returns elements left position relative to top-left of viewport
function getPosition(el) {
    return el.getBoundingClientRect().left;
}

/* DOMContentLoaded*/
});