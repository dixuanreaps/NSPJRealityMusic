﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

public partial class Website_Public_SearchEngine : System.Web.UI.Page
{
    public List<music> searchResultList;
    public string sJSON;
    public List<user> userlist;
    public string userlistforjavascript;
    string search = "";
    string filter;
    protected void Page_Load(object sender, EventArgs e)
    {
        ////prevent css
        //if (Request.QueryString["search_query"].Contains("<b>") || Request.QueryString["search_query"].Contains("</b>") || Request.QueryString["search_query"].Contains("<i>") || Request.QueryString["search_query"].Contains("</i>"))
        //{
        //    Request.QueryString["search_query"] = Server.HtmlDecode(Request.QueryString["search_query"]);
        //}
        //else
        //{
        //    Request.QueryString["search_query"] = Server.HtmlEncode(Request.QueryString["search_query"]);
        //}

        JavaScriptSerializer oSerializer = new JavaScriptSerializer();
        if (Request.QueryString["search_query"] != null)
        {

            search = Request.QueryString["search_query"];
            searching.InnerText = search;

            if (Request.QueryString["filter"] != null)
            {
                if (Request.QueryString["filter"].Equals("free"))
                {
                    All.Attributes.Add("class", "sidebuttons");
                    FreeMusic.Attributes.Add("class", "sidebuttons active");
                    filter = Request.QueryString["filter"];
                    searchResultList = SearchdatabaseFilter(search, filter);
                    searching.InnerText = search +"(free)";

                }
                else if (Request.QueryString["filter"].Equals("premium")){
                    All.Attributes.Add("class", "sidebuttons");
                    PremiumMusic.Attributes.Add("class", "sidebuttons active");
                    filter = Request.QueryString["filter"];
                    searchResultList = SearchdatabaseFilter(search, filter);
                    searching.InnerText = search + "(premium)";
                }
            }
            else
            {
                

                searchResultList = Searchdatabase(search);

                
            }
            sJSON = oSerializer.Serialize(searchResultList);
            userlist = Searchdatabaseforuserdata();
            userlistforjavascript = oSerializer.Serialize(userlist);
        }
    }

    //list of music search data without filter
    public List<music> Searchdatabase(String searchvalue)
    {
        List<music> al = new List<music>();

        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT music.* FROM music WHERE MusicTitle LIKE @search";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@search", "%" + searchvalue + "%");
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (searchvalue == null || searchvalue == "")
                    {
                        break;
                    }
                    else
                    {
                        al.Add(new music(reader.GetString(reader.GetOrdinal("audioID")), reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("username")), reader.GetString(reader.GetOrdinal("musicTitle")), reader.GetString(reader.GetOrdinal("description")), reader.GetString(reader.GetOrdinal("audioPath")), reader.GetString(reader.GetOrdinal("imagePath")), reader.GetString(reader.GetOrdinal("priceType")), reader.GetString(reader.GetOrdinal("uploadDate")), reader.GetInt32(reader.GetOrdinal("views")), reader.GetInt32(reader.GetOrdinal("likes")), reader.GetInt32(reader.GetOrdinal("noOfReports"))));
                    }
                }

                if (reader != null)
                    reader.Close();
            }
            
        }
        return al;
    }

    public List<music> SearchdatabaseFilter(String searchvalue,String filter)
    {
        List<music> al = new List<music>();

        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT music.* FROM music WHERE MusicTitle LIKE @search AND priceType = @filter";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@search", "%" + searchvalue + "%");
            command.Parameters.AddWithValue("@filter", filter);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (searchvalue == null || searchvalue == "")
                    {
                        break;
                    }
                    else
                    {
                        al.Add(new music(reader.GetString(reader.GetOrdinal("audioID")), reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("username")), reader.GetString(reader.GetOrdinal("musicTitle")), reader.GetString(reader.GetOrdinal("description")), reader.GetString(reader.GetOrdinal("audioPath")), reader.GetString(reader.GetOrdinal("imagePath")), reader.GetString(reader.GetOrdinal("priceType")), reader.GetString(reader.GetOrdinal("uploadDate")), reader.GetInt32(reader.GetOrdinal("views")), reader.GetInt32(reader.GetOrdinal("likes")), reader.GetInt32(reader.GetOrdinal("noOfReports"))));
                    }
                }

                if (reader != null)
                    reader.Close();
            }

        }
        return al;
    }

    //retrieve username of the user that upload music
    public List<user> Searchdatabaseforuserdata()
    {
        List<user> userlist = new List<user>();
        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT * FROM useraccount";
            MySqlCommand command = new MySqlCommand(query, con);
            //command.Parameters.AddWithValue("@search", searchvalue);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                        userlist.Add(new user(reader.GetInt32(reader.GetOrdinal("userID")), reader.GetString(reader.GetOrdinal("email")), reader.GetString(reader.GetOrdinal("username")), reader.GetString(reader.GetOrdinal("phoneNumber")), reader.GetString(reader.GetOrdinal("firstName")), reader.GetString(reader.GetOrdinal("lastName")), reader.GetString(reader.GetOrdinal("country")), reader.GetString(reader.GetOrdinal("imagePath")), reader.GetString(reader.GetOrdinal("birthdate"))));
                }

                if (reader != null)
                    reader.Close();
            }
        }
        return userlist;
    }


    protected void All_Click(object sender, EventArgs e)
    {
        Response.Redirect("SearchEngine.aspx?search_query=" + search);
    }

    protected void FreeMusic_Click(object sender, EventArgs e)
    {
        Response.Redirect("SearchEngine.aspx?search_query=" + search+"&filter=free");
    }

    protected void PremiumMusic_Click(object sender, EventArgs e)
    {
        Response.Redirect("SearchEngine.aspx?search_query=" + search + "&filter=premium");
    }
}