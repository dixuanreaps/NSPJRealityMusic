﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

public partial class Website_Public_SearchEngine : System.Web.UI.Page
{
    public List<music> searchResultList;
    public string sJSON;
    public List<user> userlist;
    public string userlistforjavascript;

    protected void Page_Load(object sender, EventArgs e)
    {
        string search = "";
        if (Request.QueryString["search_query"] != null)
        {
            search = Request.QueryString["search_query"];
            searching.InnerText = search;

            searchResultList = Searchdatabase(search);
            JavaScriptSerializer oSerializer = new JavaScriptSerializer();
             sJSON = oSerializer.Serialize(searchResultList);

            userlist = Searchdatabaseforuserdata();
            userlistforjavascript = oSerializer.Serialize(userlist);
        }

    }

    //list of music search data
    public List<music> Searchdatabase(String searchvalue)
    {
        List<music> al = new List<music>();

        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT music.* FROM music WHERE MusicTitle LIKE @search";
            MySqlCommand command = new MySqlCommand(query, con);
            command.Parameters.AddWithValue("@search", "%" + searchvalue + "%");
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (searchvalue == null || searchvalue == "")
                    {
                        break;
                    }
                    else
                    {
                        al.Add(new music(reader.GetString(reader.GetOrdinal("MusicID")), reader.GetInt32(reader.GetOrdinal("UserID")), reader.GetString(reader.GetOrdinal("MusicTitle")), reader.GetString(reader.GetOrdinal("Description")), reader.GetString(reader.GetOrdinal("AudioPath")), reader.GetString(reader.GetOrdinal("ImagePath")), reader.GetString(reader.GetOrdinal("PriceType")), reader.GetString(reader.GetOrdinal("UploadDate")), reader.GetInt32(reader.GetOrdinal("Views")), reader.GetInt32(reader.GetOrdinal("Likes")), reader.GetInt32(reader.GetOrdinal("NoOfReports"))));
                    }
                }

                if (reader != null)
                    reader.Close();
            }
            
        }
        return al;
    }

    //retrieve username of the user that upload music
    public List<user> Searchdatabaseforuserdata()
    {
        List<user> userlist = new List<user>();
        //sql connection, query values to database error need help
        // String connetionString = "server=localhost;user id=Desmond;password=Devils8ats;database=test;persistsecurityinfo=True;";
        string cs = ConfigurationManager.ConnectionStrings["test"].ConnectionString;
        using (MySqlConnection con = new MySqlConnection(cs))
        {

            con.Open();
            String query = "SELECT * FROM user";
            MySqlCommand command = new MySqlCommand(query, con);
            //command.Parameters.AddWithValue("@search", searchvalue);
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                        userlist.Add(new user(reader.GetInt32(0), reader.GetString(1),reader.GetString(2),reader.GetString(4),reader.GetString(5),reader.GetString(6),reader.GetString(7),reader.GetString(8)));
                }

                if (reader != null)
                    reader.Close();
            }
        }
        return userlist;
    }

}