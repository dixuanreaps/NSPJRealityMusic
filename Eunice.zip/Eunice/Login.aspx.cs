﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;




public partial class Login : System.Web.UI.Page
{
    MySql.Data.MySqlClient.MySqlConnection conn;
    MySql.Data.MySqlClient.MySqlCommand cmd;
    MySql.Data.MySqlClient.MySqlDataReader reader;
    String queryStr;
    String name;


    protected void loginEvent(object sender, EventArgs e)
    {
        String connString = System.Configuration.ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ToString();
        conn = new MySql.Data.MySqlClient.MySqlConnection(connString);
        conn.Open();
        queryStr = "";
        queryStr = "SELECT * FROM registration.userregistration WHERE userName='" + userName.Text + "' AND password='" + password.Text + "'";

        cmd = new MySql.Data.MySqlClient.MySqlCommand(queryStr, conn);

        reader = cmd.ExecuteReader();
        name = "";
        while(reader.HasRows && reader.Read())
        {
            name = reader.GetString(reader.GetOrdinal("firstName")) + " " +
                reader.GetString(reader.GetOrdinal("lastName"));
                
        }

        if (reader.HasRows)
        {
            Session["uname"] = name;
            Response.BufferOutput = true;
            Response.Redirect("UserProfile.aspx", false);
        }
        else
        {
            
            string loginStatus = "invalid user!";
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + loginStatus + "');", true);
            userName.Text = string.Empty;
            password.Text = string.Empty;
        }

        reader.Close();
        conn.Close();
    }
}
    
