﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserProfile : System.Web.UI.Page
{
    String name;
    protected void Page_Load(object sender, EventArgs e)
    {
        name = (String)(Session["uname"]);
        userLabel.Text = name;

        

    }

    protected void changePasswordPage(object sender, EventArgs e)
    {
        Response.Redirect("UserProfile_ChangePassword.aspx");
    }

    protected void changeImagePage(object sender, EventArgs e)
    {
        Response.Redirect("UserProfile_ChangePic.aspx");
    }

    protected void editProfilePage(object sender, EventArgs e)
    {
        Response.Redirect("UserProfile_EditProfile.aspx");
    }



    protected void logOutEvent(object sender, System.EventArgs e)
    {
       
        Response.Redirect("LogOut.aspx");
    }
}